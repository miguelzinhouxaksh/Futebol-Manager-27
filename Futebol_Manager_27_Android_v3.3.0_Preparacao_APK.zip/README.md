# Futebol Manager 27 — Android 1.4.0 (protótipo em desenvolvimento)

Projeto Android nativo em Kotlin + Jetpack Compose.

## Abrir e executar
1. Extraia o ZIP e abra a pasta `fm27work` no Android Studio.
2. Configure JDK 17 e Android SDK 35.
3. Sincronize o projeto Gradle.
4. Execute em um emulador ou aparelho Android (API 26+).

## Funcionalidades presentes no código
- Fluxo inicial de carreira: país → divisão → clube.
- Catálogo local demonstrativo e consulta opcional ao TheSportsDB para clubes, escudos, estádios e competições.
- Elenco de jogadores fictícios gerados proceduralmente.
- Painel, elenco, competições demonstrativas, calendário, finanças e simulação de partidas.
- Alternância de adversário por rodada usando o catálogo local.
- Persistência local da seleção do clube, rodada, partidas disputadas, pontos, saldo, orçamento, receitas e último resultado.
- Interface escura com detalhes em verde-lima.

## Limitações conhecidas — não é um jogo final
- A tabela/competições ainda são demonstrativas; não existe campeonato completo com todos os clubes e calendário real.
- O motor de partidas é simplificado e não simula escalação, tática, substituições, lesões ou suspensões de forma completa.
- O mercado de transferências, negociações reais, contratos e evolução de carreira ainda não estão completos.
- A população de jogadores é fictícia; dados remotos de clubes e escudos têm cobertura variável.
- TheSportsDB é uma fonte colaborativa. Disponibilidade, precisão e direitos de uso de imagens não são garantidos.
- O adversário é escolhido a partir de uma lista local reduzida; não representa uma temporada completa.
- Esta entrega contém código-fonte. Nenhum APK foi compilado ou validado nesta execução.

## Dependências
Android Gradle Plugin, Kotlin, Jetpack Compose, Retrofit, Gson, Coil e Coroutines, conforme `app/build.gradle.kts`.

## Aviso sobre publicação
Antes de distribuir comercialmente, obtenha autorização para marcas, escudos, nomes e imagens protegidos e confirme os direitos de redistribuição dos dados.


## Motor de campeonato (módulo novo em 1.2.0)
- Novo `LeagueEngine`: gera calendário completo de turno e returno pelo algoritmo round-robin, inclusive com número ímpar de clubes.
- Calcula classificação por pontos (3/1/0), vitórias, empates, derrotas, gols pró/contra e saldo; desempata por pontos, saldo, gols pró e nome.
- Valida IDs duplicados, resultados repetidos, partidas desconhecidas e placares negativos.
- Testes unitários adicionados para calendário par/ímpar, pontuação e IDs duplicados.
- **Importante:** este motor está implementado como módulo Kotlin, mas ainda precisa ser ligado às telas e ao fluxo de salvar/avançar rodada antes de ser considerado funcional no jogo completo.


## Integração do campeonato na interface (1.3.0)
- A tela Competições agora usa a classificação calculada pelo `LeagueEngine`, em vez da tabela fixa demonstrativa.
- A tela Calendário usa o confronto do clube selecionado na rodada corrente, respeitando mando de campo.
- A simulação registra o resultado na classificação da sessão e calcula os pontos do clube considerando se jogou em casa ou fora.
- O calendário é gerado em turno e returno para os clubes disponíveis no catálogo da divisão.
- Limitação atual: resultados da tabela integrada ainda ficam em memória durante a sessão e não são restaurados após fechar o app; a lista de clubes ainda é um catálogo reduzido. A temporada completa, transferências e táticas avançadas seguem pendentes.


## Persistência da temporada (1.4.0)
- Resultados individuais do campeonato agora são serializados em JSON e salvos localmente por carreira (divisão + clube).
- Ao reabrir o aplicativo, a classificação recalcula os pontos, vitórias, empates, derrotas e gols a partir dos resultados persistidos.
- Proteção contra registrar novamente uma partida já concluída.
- Versão do aplicativo atualizada para 1.4.0.
- Continua sendo código-fonte Android; APK não compilado nem validado neste ambiente.

## Mercado de transferências (1.5.0)
- Nova área Transferências na navegação principal.
- Lista de atletas fictícios disponíveis com busca por nome/nacionalidade e filtro por posição.
- Exibe OVR, potencial, idade, nacionalidade, valor de mercado e salário semanal.
- Contratação cobra taxa estimada de 125% do valor de mercado, limitada ao orçamento disponível.
- Jogadores contratados e orçamento são persistidos localmente por clube/carreira.
- Limitação: mercado ainda é local e demonstrativo; não há clubes vendedores, contrapropostas, empréstimos, vendas ou negociação salarial.
- Validação: não foi possível executar Gradle/Android build neste ambiente porque não há Gradle instalado nem Gradle Wrapper no projeto. A compilação final deve ser validada no Android Studio com JDK 17 e SDK 35.


## Versão 1.6.0 — integração do elenco e vendas

- O mercado e o elenco agora usam a mesma geração determinística de jogadores por clube.
- Jogadores contratados passam a aparecer no elenco da carreira.
- A tela de transferências permite vender atletas contratados por 80% do valor de mercado; o valor retorna ao orçamento e ao caixa.
- O elenco permanece baseado em texto e atributos, sem retratos/fotos de jogadores.
- IDs de contratações continuam persistidos por clube.

**Limitações:** o mercado segue demonstrativo, sem clubes vendedores, contrapropostas, empréstimos ou negociação salarial. Os logos de competições ainda dependem dos dados retornados pelo serviço externo e não foram substituídos por um pacote local oficial. Esta versão ainda precisa ser compilada e testada no Android Studio; não há APK validado nesta entrega.

## Versão 1.7.0 — catálogo visual local de competições

- Criado `CompetitionCatalog` com identidades visuais locais padronizadas para competições nacionais, continentais e mundiais.
- A tela de competições deixou de depender dos logos retornados por uma API externa, evitando emblemas incorretos ou ausentes na lista principal.
- A classificação agora exibe jogos, vitórias, empates, derrotas, saldo de gols e pontos.
- A tela lista resultados já registrados na temporada.
- Mantida a apresentação do elenco sem retratos ou rostos de atletas.
- Versão do aplicativo atualizada para 1.7.0 (versionCode 16).

**Limitações desta entrega:** as marcas do catálogo são monogramas/identidades gráficas próprias, não reproduções oficiais dos escudos protegidos das competições. O calendário ainda depende do conjunto de clubes carregado para a carreira e os resultados são os efetivamente simulados no jogo. Não foi possível compilar o APK neste ambiente por ausência de Gradle/Gradle Wrapper; a compilação precisa ser validada no Android Studio.

## Versão 1.8.0 — centro de treinamento e evolução

- Adicionada a área **Treino** na navegação principal.
- Treinos individuais para atletas do elenco, com filtro por posição e sem fotos/rostos.
- Cada sessão custa € 20.000; a cada três sessões acumuladas o jogador recebe +1 OVR, limitado ao potencial.
- Progresso de treino e evolução são salvos localmente por clube/carreira.
- A tela mostra OVR, potencial e sessões acumuladas.
- Versão do aplicativo atualizada para 1.8.0 (versionCode 17).

**Limitações:** o treino é individual e simplificado; ainda não há calendário semanal de treinos, comissão técnica, fadiga ou treino coletivo. A compilação Android não foi executada neste ambiente; valide no Android Studio com JDK 17 e Android SDK 35 antes de instalar.

## Versão 1.9.0 — Escalação e tática
- Nova área Tática na navegação principal.
- Seleção de formação: 4-3-3, 4-4-2, 3-5-2 e 4-2-3-1.
- Seleção de até 11 titulares a partir do elenco da carreira, incluindo contratações.
- Formação e titulares persistidos por clube no armazenamento local.
- Sem retratos ou fotografias de jogadores.
- Limitação: a escalação ainda é uma configuração de carreira e não altera a lógica/atributos da simulação de partidas; integração tática ao motor de jogo permanece como próxima etapa.
- Build Android não executado neste ambiente; validar no Android Studio com JDK 17 e SDK 35.

## Versão 2.0.0 — Motor de partidas com influência tática

- A simulação agora recebe a formação escolhida (4-3-3, 4-4-2, 3-5-2 ou 4-2-3-1).
- A média de OVR dos titulares selecionados influencia expectativa de gols, posse e finalizações da equipe do usuário quando atua como mandante.
- Quando não há titulares salvos, o motor utiliza os 11 melhores atletas do elenco como escalação sugerida.
- O efeito tático é moderado e mantém aleatoriedade e vantagem do adversário.
- Limitação: ainda não há substituições durante a partida nem ajuste tático em tempo real; a influência tática é aplicada antes da simulação.
- Build Android não executado neste ambiente; requer Android Studio, JDK 17 e SDK Android configurado.

## Versão 2.1.0 — eventos de partida
- A simulação agora gera ocorrências disciplinares e físicas: cartões amarelos, possibilidade de cartão vermelho e eventos de lesão.
- O resumo pós-jogo apresenta cartões vermelhos e lesões, além de posse e finalizações.
- Os dois novos indicadores do último resultado são persistidos localmente.
- Observação: lesões e expulsões aparecem como eventos agregados da partida; ainda não há associação a atletas específicos, duração de recuperação ou suspensão automática por jogador.
- O APK ainda precisa ser compilado e testado no Android Studio.

## v2.2.0 — Disponibilidade individual do elenco
- Eventos disciplinares e físicos passam a ser atribuídos a atletas titulares específicos.
- Acúmulo de cinco cartões amarelos gera suspensão de uma partida; cartão vermelho também gera suspensão.
- Lesões afastam o atleta por 1 a 3 rodadas simuladas.
- A escalação automática e a seleção de titulares desconsideram atletas indisponíveis; situação aparece no elenco.
- Estado de disponibilidade é persistido por clube/carreira.
- Limitação: ainda não há tela de substituições em tempo real; os eventos são processados no fechamento da partida.
- Build Android não executado neste ambiente; validar no Android Studio com JDK 17 e SDK 35.


## Versão 2.3.0 — Banco, substituições automáticas e fadiga

- Banco de reservas de até 9 atletas disponível no planejamento interno da partida.
- Até 5 substituições automáticas por partida, priorizando titulares com baixa energia e reservas de posição compatível.
- Fadiga individual acumulada por atleta e persistida por clube/carreira.
- Recuperação de energia entre rodadas; atletas que não entram recuperam mais energia.
- O OVR efetivo da equipe considera o desgaste, e as trocas são incluídas no resumo pós-jogo.
- Mantém o elenco sem fotografias ou retratos de jogadores.

Limitações: as substituições são automáticas e ocorrem na simulação resumida; ainda não há controle minuto a minuto, escolha manual de substitutos ou animação de partida. O projeto precisa ser compilado e testado no Android Studio; esta entrega é código-fonte, não APK.


## Versão 2.4.0 — contratos e moral (30/10/2026)
- Adicionado `PlayerCareerEngine` com cálculo de proposta salarial sugerida, decisão de renovação, duração contratual em rodadas e efeitos na moral.
- Moral agora pode modificar o overall efetivo usado pelo `MatchSquadManager` (bônus/penalidade), mantendo compatibilidade com chamadas antigas por parâmetro opcional.
- Adicionados testes unitários para renovação e impacto da moral.
- Limitação: a camada de regras está implementada, mas ainda não existe tela de negociação nem persistência individual dos estados de moral/contrato na interface da carreira.
- APK ainda não compilado nem testado em dispositivo.


## Versão 2.5.0 — contratos, moral e folha salarial

- Nova tela **Contratos** na navegação principal, com salário semanal, duração contratual e moral individual.
- Sistema de moral por atleta (0–100), com faixas qualitativas e impacto no OVR efetivo utilizado pelo motor de escalação.
- Moral é atualizada após partidas conforme titularidade e resultado; dados persistidos por clube.
- Renovações negociáveis: salário semanal e duração de 8 a 24 rodadas; ofertas abaixo do mínimo são recusadas e afetam a moral.
- Folha salarial calculada a partir dos salários individuais vigentes e descontada do caixa ao avançar a rodada.
- Salvamento automático local por SharedPreferences/Gson para contratos, moral e demais dados de carreira já existentes.
- `versionName` atualizado para 2.5.0 (`versionCode` 24).

**Validação pendente:** o ambiente desta entrega não possui Gradle/Gradle Wrapper nem Android SDK disponíveis, portanto não foi possível compilar ou executar testes Android aqui. O projeto permanece código-fonte e deve ser sincronizado/compilado no Android Studio (JDK 17, SDK 35) antes de gerar um APK instalável.


## Versão 2.6.0 — ciclo de temporadas

- A carreira agora identifica e salva o número da temporada atual.
- Ao concluir a última rodada do calendário, a classificação final é calculada e um resumo da temporada é arquivado localmente.
- A competição inicia automaticamente uma nova temporada na rodada 1, com pontos, jogos e resultados reiniciados; o saldo financeiro e o elenco são preservados.
- A receita acumulada da temporada recomeça no novo campeonato.
- A tela inicial e o cabeçalho mostram a temporada atual.

**Validação:** o código-fonte foi atualizado e será empacotado em ZIP. A compilação Android e a execução dos testes Gradle ainda dependem de um ambiente com Gradle/Android SDK.


## Versão 2.7.0 — rodadas completas e simulação dos rivais
- Ao jogar a partida do seu clube, os demais confrontos daquela mesma rodada também são simulados automaticamente.
- A classificação passa a refletir todos os clubes e jogos concluídos, não apenas as partidas do usuário.
- Resultados dos confrontos da rodada são persistidos juntos; a simulação dos rivais usa uma semente estável por temporada/rodada/confronto para evitar resultados inconsistentes ao restaurar a carreira.
- Adicionado teste unitário para garantir que a rodada seja completada e que o placar do usuário seja preservado.
- O histórico local mantém até dez resumos de temporadas anteriores.

**Validação pendente:** testes e build Android completos dependem de Gradle/Android SDK. Esta entrega é código-fonte ZIP, não APK instalado.


## Versão 2.8.0 — negociação de vendas
- A venda de jogadores passou a abrir uma janela de negociação em vez de transferir o atleta imediatamente.
- Cada negociação apresenta uma oferta inicial de 80% do valor de mercado e permite uma contraproposta de 110%.
- A lógica do clube comprador aceita contrapropostas dentro do limite simulado de 115% do valor de mercado; pedidos acima disso são recusados.
- O valor acordado continua atualizando o orçamento de transferências, o caixa e a lista de atletas contratados, com persistência local.
- Adicionados testes unitários para oferta inicial, contraproposta, aceite e limites do valor de venda.

**Validação pendente:** o ambiente não possui Gradle/Gradle Wrapper nem Android SDK; portanto, não foi possível executar build Android nem testes Gradle. A entrega é o código-fonte ZIP, não um APK.


## Versão 2.9.0 — negociação de contratações
- Contratações agora começam com uma negociação: o clube vendedor informa seu pedido e o usuário pode ajustar a própria oferta.
- O pedido inicial é de 125% do valor de mercado; propostas entre 110% e 125% são aceitas pelo motor de negociação.
- Ofertas abaixo do limite ou acima do pedido são recusadas com mensagem explicativa.
- A contratação só é concluída quando a oferta é aceita e cabe no orçamento; o fluxo existente atualiza elenco, orçamento e caixa com o valor acordado.
- Foram adicionados testes unitários para pedido do vendedor, faixa de aceite e cálculo do valor final.

**Validação pendente:** não há Gradle/Gradle Wrapper nem Android SDK neste ambiente. O ZIP contém o código-fonte; ainda não é um APK compilado ou testado em dispositivo.


## v3.0.0 — propostas automáticas de clubes

- O mercado gera propostas de clubes do universo do jogo por jogadores contratados.
- Cada oferta identifica o clube interessado e o valor oferecido.
- As propostas são determinísticas por clube do usuário, temporada, rodada e jogador: reabrir a tela não altera a oferta da mesma rodada.
- A oferta muda quando a carreira avança para outra rodada.
- O treinador pode aceitar a oferta ou enviar contraproposta conforme as regras de negociação já existentes.
- Venda aceita remove o atleta do elenco e atualiza orçamento de transferências e caixa.
- Adicionados testes para estabilidade e variação das propostas entre rodadas.
- A versão do app passa para 3.0.0 (versionCode 29).

**Limitações:** as propostas são simuladas localmente e não representam clubes conectados a uma base mundial completa. Ainda não há empréstimos nem negociação de cláusulas. A compilação Android/instalação em dispositivo precisa ser feita no Android Studio com JDK 17 e SDK 35; este ambiente não dispõe de Gradle/Wrapper nem SDK Android.


## v3.1.0 — empréstimos de jogadores

- A tela de transferências permite trazer atletas por empréstimo, sem taxa de compra.
- Duração selecionável de 8, 12, 16 ou 24 rodadas.
- O clube assume 50% do salário semanal durante o empréstimo.
- Contratos de empréstimo são salvos na carreira e exibidos em seção própria do mercado.
- O prazo diminui a cada rodada disputada; ao fim, o jogador retorna automaticamente e sai do elenco emprestado.
- Testes unitários cobrem custo salarial, criação do contrato, prazo e retorno automático.
- Versão do app atualizada para 3.1.0 (versionCode 30).

**Limitações:** a origem dos atletas emprestados é representada por clubes parceiros fictícios; ainda não há negociação de cláusulas ou empréstimo de jogadores do usuário para clubes externos. APK não compilado neste ambiente por ausência de Gradle/Wrapper e Android SDK.


## Versão 3.2.0 — Empréstimos de saída
- Cessão temporária de jogadores próprios para clubes parceiros.
- Contribuição de 50% do salário semanal por padrão, com custo líquido atualizado para o clube cedente.
- Jogadores cedidos ficam fora da escalação durante o contrato e retornam automaticamente ao fim do prazo, sem perder vínculo com o clube.
- Contratos de empréstimo de saída salvos automaticamente por carreira.

## v3.3.0 — Preparação da compilação Android
- Adicionado bootstrap `gradlew`/`gradlew.bat` para instalar Gradle 8.9 quando houver conexão.
- Adicionada automação GitHub Actions para instalar Android SDK 35, executar testes unitários e gerar `app-debug.apk`.
- O APK é publicado como artefato da execução do workflow `Build Android APK`.

### Gerar APK localmente
Requisitos: JDK 17, conexão à internet na primeira execução e Android SDK com platform 35/build-tools 35.0.0.
- Linux/macOS: `./gradlew testDebugUnitTest assembleDebug`
- Windows: `gradlew.bat testDebugUnitTest assembleDebug`
- Saída: `app/build/outputs/apk/debug/app-debug.apk`

### Gerar o APK pelo GitHub Actions (sem instalar Android Studio no PC)
1. Crie um repositório no GitHub (pode ser privado).
2. Extraia este ZIP e envie o conteúdo da pasta do projeto para a raiz do repositório. A pasta `.github/workflows` precisa ser enviada também.
3. Abra a aba **Actions** do repositório e selecione **Build Android APK**.
4. Aguarde a execução terminar. Se o teste ou a compilação falhar, abra a execução para consultar o log do erro.
5. Quando a execução ficar verde, abra-a e baixe o artefato **Futebol-Manager-27-APK-debug**. Dentro dele estará `app-debug.apk`.
6. Transfira o APK para o Android e instale. Para instalação fora da Play Store, o Android poderá pedir autorização para instalar apps dessa fonte.

Observação: este fluxo prepara a compilação automatizada, mas o APK só passa a existir depois que o workflow for executado com sucesso. O APK `debug` é para testes; uma versão de distribuição exige assinatura de release.
