package com.futebol27.manager

/** Identidades locais em texto/cores: não dependem de logos remotos inconsistentes. */
data class CompetitionIdentity(
    val name: String,
    val region: String,
    val country: String,
    val mark: String,
    val colorHex: Long,
    val format: String
)

object CompetitionCatalog {
    val all = listOf(
        CompetitionIdentity("Brasileirão Série A", "CONMEBOL", "Brasil", "BR", 0xFF2D9CDB, "Pontos corridos • 20 clubes"),
        CompetitionIdentity("Brasileirão Série B", "CONMEBOL", "Brasil", "B", 0xFF27AE60, "Pontos corridos • 20 clubes"),
        CompetitionIdentity("Copa do Brasil", "CONMEBOL", "Brasil", "CB", 0xFFF2C94C, "Mata-mata"),
        CompetitionIdentity("Copa Libertadores", "CONMEBOL", "América do Sul", "LIB", 0xFFF2994A, "Fase de grupos e mata-mata"),
        CompetitionIdentity("Copa Sudamericana", "CONMEBOL", "América do Sul", "SUD", 0xFFEB5757, "Fase de grupos e mata-mata"),
        CompetitionIdentity("Premier League", "UEFA", "Inglaterra", "PL", 0xFF9B51E0, "Pontos corridos • 20 clubes"),
        CompetitionIdentity("LaLiga", "UEFA", "Espanha", "LL", 0xFFEB5757, "Pontos corridos • 20 clubes"),
        CompetitionIdentity("Bundesliga", "UEFA", "Alemanha", "BL", 0xFFEB5757, "Pontos corridos • 18 clubes"),
        CompetitionIdentity("Serie A", "UEFA", "Itália", "SA", 0xFF27AE60, "Pontos corridos • 20 clubes"),
        CompetitionIdentity("Ligue 1", "UEFA", "França", "L1", 0xFF2D9CDB, "Pontos corridos • 18 clubes"),
        CompetitionIdentity("UEFA Champions League", "UEFA", "Europa", "UCL", 0xFF2F80ED, "Fase de liga e mata-mata"),
        CompetitionIdentity("UEFA Europa League", "UEFA", "Europa", "UEL", 0xFFF2994A, "Fase de liga e mata-mata"),
        CompetitionIdentity("AFC Champions League", "AFC", "Ásia", "AFC", 0xFF56CCF2, "Fase de liga e mata-mata"),
        CompetitionIdentity("CAF Champions League", "CAF", "África", "CAF", 0xFF27AE60, "Fase de grupos e mata-mata"),
        CompetitionIdentity("CONCACAF Champions Cup", "CONCACAF", "América do Norte", "CC", 0xFF6FCF97, "Mata-mata"),
        CompetitionIdentity("FIFA Club World Cup", "FIFA", "Mundial", "FIFA", 0xFFBB6BD9, "Fase de grupos e mata-mata")
    )

    fun forCountry(country: String): List<CompetitionIdentity> = all.filter {
        it.country == country || it.country == "Europa" || it.country == "América do Sul" || it.country == "Mundial" ||
            (country == "Brasil" && it.name.contains("Brasileirão"))
    }.distinctBy { it.name }
}
