package com.futebol27.manager

data class LeagueFixture(
    val id: Int, val round: Int, val homeClubId: Int, val awayClubId: Int, val leg: Int
)
data class Standing(
    val clubId: Int, val clubName: String, val played: Int = 0,
    val wins: Int = 0, val draws: Int = 0, val losses: Int = 0,
    val goalsFor: Int = 0, val goalsAgainst: Int = 0
) {
    val goalDifference: Int get() = goalsFor - goalsAgainst
    val points: Int get() = wins * 3 + draws
}
data class RecordedFixtureResult(val fixtureId: Int, val homeGoals: Int, val awayGoals: Int)

/** Campeonato completo em turno e returno, com classificação por pontos, saldo e gols pró. */
object LeagueEngine {
    fun createDoubleRoundRobin(clubs: List<Club>): List<LeagueFixture> {
        require(clubs.size >= 2) { "O campeonato precisa de pelo menos dois clubes." }
        require(clubs.map { it.id }.distinct().size == clubs.size) { "IDs de clubes duplicados." }
        val bye = -1
        val rotation = clubs.map { it.id }.toMutableList().apply { if (size % 2 != 0) add(bye) }
        val slots = rotation.size
        val firstLeg = mutableListOf<LeagueFixture>()
        var id = 1
        repeat(slots - 1) { roundIndex ->
            for (i in 0 until slots / 2) {
                val a = rotation[i]
                val b = rotation[slots - 1 - i]
                if (a != bye && b != bye) {
                    val home = if (roundIndex % 2 == 0) a else b
                    val away = if (roundIndex % 2 == 0) b else a
                    firstLeg += LeagueFixture(id++, roundIndex + 1, home, away, 1)
                }
            }
            val last = rotation.removeAt(rotation.lastIndex)
            rotation.add(1, last)
        }
        return firstLeg + firstLeg.map { f ->
            LeagueFixture(id++, f.round + slots - 1, f.awayClubId, f.homeClubId, 2)
        }
    }

    /** Completa todos os jogos de uma rodada: preserva o resultado do clube do usuário
     * e simula automaticamente os demais confrontos ainda não registrados. */
    fun completeRound(
        fixtures: List<LeagueFixture>,
        existingResults: List<RecordedFixtureResult>,
        round: Int,
        userFixtureId: Int,
        userHomeGoals: Int,
        userAwayGoals: Int,
        simulate: (LeagueFixture) -> RecordedFixtureResult
    ): List<RecordedFixtureResult> {
        require(userHomeGoals >= 0 && userAwayGoals >= 0) { "Gols negativos." }
        require(fixtures.any { it.id == userFixtureId && it.round == round }) { "Partida do usuário não pertence à rodada." }
        val resultById = existingResults.associateBy { it.fixtureId }.toMutableMap()
        require(resultById.size == existingResults.size) { "Resultado duplicado." }
        val userResult = RecordedFixtureResult(userFixtureId, userHomeGoals, userAwayGoals)
        resultById[userFixtureId] = userResult
        fixtures.filter { it.round == round && it.id !in resultById }.forEach { fixture ->
            val generated = simulate(fixture)
            require(generated.fixtureId == fixture.id) { "Simulação retornou partida incorreta." }
            require(generated.homeGoals >= 0 && generated.awayGoals >= 0) { "Gols negativos." }
            resultById[fixture.id] = generated
        }
        return resultById.values.sortedBy { it.fixtureId }
    }

    fun standings(clubs: List<Club>, fixtures: List<LeagueFixture>, results: List<RecordedFixtureResult>): List<Standing> {
        val byFixture = fixtures.associateBy { it.id }
        require(results.map { it.fixtureId }.distinct().size == results.size) { "Resultado duplicado." }
        require(results.all { it.fixtureId in byFixture }) { "Partida desconhecida." }
        require(results.all { it.homeGoals >= 0 && it.awayGoals >= 0 }) { "Gols negativos." }
        val rows = clubs.associate { it.id to Standing(it.id, it.name) }.toMutableMap()
        results.forEach { result ->
            val f = byFixture.getValue(result.fixtureId)
            val h = rows[f.homeClubId] ?: error("Mandante ausente")
            val a = rows[f.awayClubId] ?: error("Visitante ausente")
            val hw = result.homeGoals > result.awayGoals
            val aw = result.homeGoals < result.awayGoals
            rows[h.clubId] = h.copy(
                played=h.played+1, wins=h.wins+if(hw) 1 else 0,
                draws=h.draws+if(!hw && !aw) 1 else 0, losses=h.losses+if(aw) 1 else 0,
                goalsFor=h.goalsFor+result.homeGoals, goalsAgainst=h.goalsAgainst+result.awayGoals
            )
            rows[a.clubId] = a.copy(
                played=a.played+1, wins=a.wins+if(aw) 1 else 0,
                draws=a.draws+if(!hw && !aw) 1 else 0, losses=a.losses+if(hw) 1 else 0,
                goalsFor=a.goalsFor+result.awayGoals, goalsAgainst=a.goalsAgainst+result.homeGoals
            )
        }
        return rows.values.sortedWith(compareByDescending<Standing> { it.points }
            .thenByDescending { it.goalDifference }.thenByDescending { it.goalsFor }
            .thenBy { it.clubName.lowercase() })
    }
}
