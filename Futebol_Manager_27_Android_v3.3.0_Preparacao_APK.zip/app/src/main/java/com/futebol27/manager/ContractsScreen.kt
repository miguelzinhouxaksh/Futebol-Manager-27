package com.futebol27.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ContractBg = Color(0xFF070A10)
private val ContractPanel = Color(0xFF121824)
private val ContractLime = Color(0xFFC5FF36)
private val ContractMuted = Color(0xFF8D98AA)

@Composable
fun ContractsScreen(
    club: Club,
    players: List<Player>,
    states: Map<String, PlayerCareerState>,
    balance: Long,
    onRenew: (Player, ContractOffer) -> String
) {
    var selected by remember { mutableStateOf<Player?>(null) }
    var salaryText by remember { mutableStateOf("") }
    var rounds by remember { mutableIntStateOf(12) }
    var feedback by remember { mutableStateOf("") }
    val totalWages = players.sumOf { (states[it.id.toString()]?.requestedWeeklySalary ?: 0L).takeIf { v -> v > 0 } ?: it.weeklySalary }
    LazyColumn(Modifier.fillMaxSize().background(ContractBg), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            Text("GESTÃO DE CONTRATOS", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
            Text(club.name, color = ContractMuted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryTile("FOLHA / SEMANA", "€ ${"%,d".format(totalWages)}", Modifier.weight(1f))
                SummaryTile("CAIXA", "€ ${"%,d".format(balance)}", Modifier.weight(1f))
            }
            Text("Moral individual e situação contratual", color = ContractLime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        items(players, key = { it.id }) { player ->
            val state = states[player.id.toString()] ?: PlayerCareerState()
            Card(colors = CardDefaults.cardColors(containerColor = ContractPanel), shape = RoundedCornerShape(13.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(player.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${player.position} • OVR ${player.overall} • ${state.contractRoundsRemaining} rodadas restantes", color = ContractMuted, fontSize = 10.sp)
                        }
                        Text("${state.morale}/100", color = when { state.morale >= 70 -> ContractLime; state.morale >= 45 -> Color(0xFFFFC15A); else -> Color(0xFFFF7777) }, fontWeight = FontWeight.Black)
                    }
                    LinearProgressIndicator(progress = { state.morale / 100f }, modifier = Modifier.fillMaxWidth().height(5.dp), color = ContractLime, trackColor = Color(0xFF30394A))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Moral: ${state.moraleLabel}", color = ContractMuted, fontSize = 10.sp)
                        Text("€ ${"%,d".format(state.requestedWeeklySalary.takeIf { it > 0 } ?: player.weeklySalary)}/sem.", color = Color.White, fontSize = 10.sp)
                    }
                    Text(if (state.contractRoundsRemaining <= 2) "Contrato próximo do fim" else "Contrato ativo", color = if (state.contractRoundsRemaining <= 2) Color(0xFFFFC15A) else ContractMuted, fontSize = 9.sp)
                    OutlinedButton(onClick = {
                        selected = player
                        salaryText = PlayerCareerEngine.suggestedOffer(player, state).weeklySalary.toString()
                        rounds = 12
                        feedback = ""
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = ContractLime)) {
                        Icon(Icons.Default.Edit, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Negociar renovação")
                    }
                }
            }
        }
    }
    selected?.let { player ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("Renovar contrato • ${player.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Salário semanal atual: € ${"%,d".format(player.weeklySalary)}")
                    OutlinedTextField(value = salaryText, onValueChange = { salaryText = it.filter(Char::isDigit).take(12) }, label = { Text("Novo salário semanal (€)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    Text("Duração: $rounds rodadas")
                    Slider(value = rounds.toFloat(), onValueChange = { rounds = it.toInt() }, valueRange = 8f..24f, steps = 7)
                    if (feedback.isNotBlank()) Text(feedback, color = ContractLime)
                }
            },
            confirmButton = { TextButton(onClick = {
                val salary = salaryText.toLongOrNull() ?: 0L
                feedback = onRenew(player, ContractOffer(salary, rounds))
                if (feedback.startsWith("Renovação aceita")) selected = null
            }) { Text("Enviar proposta") } },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Fechar") } }
        )
    }
}

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = ContractPanel)) {
        Column(Modifier.padding(11.dp)) {
            Text(label, color = ContractMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(value, color = ContractLime, fontSize = 14.sp, fontWeight = FontWeight.Black)
        }
    }
}
