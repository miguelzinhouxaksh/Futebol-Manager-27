package com.futebol27.manager

import android.content.Context
import com.google.gson.reflect.TypeToken
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

/** Catálogo mundial inicial. Os nomes de consulta seguem os identificadores de liga do TheSportsDB. */
data class WorldLeague(
    val country: String,
    val name: String,
    val apiName: String,
    val tier: String,
    val confederation: String
)

data class WorldCompetition(
    val id: String,
    val name: String,
    val country: String,
    val logoUrl: String = "",
    val confederation: String
)

private data class TeamsResponse(val teams: List<RemoteTeam>?)
private data class LeaguesResponse(val leagues: List<RemoteLeague>?)
private data class RemoteTeam(
    val idTeam: String?, val strTeam: String?, val strTeamShort: String?,
    val strStadium: String?, val intStadiumCapacity: String?, val strBadge: String?,
    val strCountry: String?, val strLeague: String?
)
private data class RemoteLeague(
    val idLeague: String?, val strLeague: String?, val strCountry: String?, val strBadge: String?
)

private interface SportsDbApi {
    @GET("search_all_teams.php")
    suspend fun teams(@Query("l") league: String): TeamsResponse

    @GET("search_all_leagues.php")
    suspend fun leagues(@Query("c") country: String, @Query("s") sport: String = "Soccer"): LeaguesResponse
}

object WorldFootballRepository {
    private val api: SportsDbApi = Retrofit.Builder()
        .baseUrl("https://www.thesportsdb.com/api/v1/json/123/")
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(SportsDbApi::class.java)

    val leagues = listOf(
        WorldLeague("Brasil", "Brasileirão Série A", "Brazilian Serie A", "1ª divisão", "CONMEBOL"),
        WorldLeague("Brasil", "Brasileirão Série B", "Brazilian Serie B", "2ª divisão", "CONMEBOL"),
        WorldLeague("Brasil", "Brasileirão Série C", "Brazilian Serie C", "3ª divisão", "CONMEBOL"),
        WorldLeague("Argentina", "Primera División", "Argentine Primera Division", "1ª divisão", "CONMEBOL"),
        WorldLeague("Chile", "Primera División", "Chilean Primera Division", "1ª divisão", "CONMEBOL"),
        WorldLeague("Colômbia", "Primera A", "Colombian Primera A", "1ª divisão", "CONMEBOL"),
        WorldLeague("Uruguai", "Primera División", "Uruguayan Primera Division", "1ª divisão", "CONMEBOL"),
        WorldLeague("Inglaterra", "Premier League", "English Premier League", "1ª divisão", "UEFA"),
        WorldLeague("Inglaterra", "Championship", "English League Championship", "2ª divisão", "UEFA"),
        WorldLeague("Espanha", "LaLiga", "Spanish La Liga", "1ª divisão", "UEFA"),
        WorldLeague("Espanha", "LaLiga 2", "Spanish Segunda Division", "2ª divisão", "UEFA"),
        WorldLeague("Alemanha", "Bundesliga", "German Bundesliga", "1ª divisão", "UEFA"),
        WorldLeague("Alemanha", "2. Bundesliga", "German 2. Bundesliga", "2ª divisão", "UEFA"),
        WorldLeague("Itália", "Serie A", "Italian Serie A", "1ª divisão", "UEFA"),
        WorldLeague("Itália", "Serie B", "Italian Serie B", "2ª divisão", "UEFA"),
        WorldLeague("França", "Ligue 1", "French Ligue 1", "1ª divisão", "UEFA"),
        WorldLeague("França", "Ligue 2", "French Ligue 2", "2ª divisão", "UEFA"),
        WorldLeague("Portugal", "Liga Portugal", "Portuguese Primeira Liga", "1ª divisão", "UEFA"),
        WorldLeague("Países Baixos", "Eredivisie", "Dutch Eredivisie", "1ª divisão", "UEFA"),
        WorldLeague("Escócia", "Premiership", "Scottish Premier League", "1ª divisão", "UEFA"),
        WorldLeague("Turquia", "Süper Lig", "Turkish Super Lig", "1ª divisão", "UEFA"),
        WorldLeague("Arábia Saudita", "Saudi Pro League", "Saudi Arabian Pro League", "1ª divisão", "AFC"),
        WorldLeague("Japão", "J1 League", "Japanese J League", "1ª divisão", "AFC"),
        WorldLeague("Coreia do Sul", "K League 1", "Korean K League 1", "1ª divisão", "AFC"),
        WorldLeague("Estados Unidos", "MLS", "American Major League Soccer", "1ª divisão", "CONCACAF"),
        WorldLeague("México", "Liga MX", "Mexican Primera League", "1ª divisão", "CONCACAF"),
        WorldLeague("África do Sul", "Premier Soccer League", "South African Premier Soccer League", "1ª divisão", "CAF"),
        WorldLeague("Egito", "Egyptian Premier League", "Egyptian Premier League", "1ª divisão", "CAF"),
        WorldLeague("Marrocos", "Botola Pro", "Moroccan Botola Pro", "1ª divisão", "CAF"),
        WorldLeague("Austrália", "A-League", "Australian A-League", "1ª divisão", "AFC"),
        WorldLeague("Brasil", "Copa do Brasil", "Brazilian Cup", "Copa nacional", "CONMEBOL"),
        WorldLeague("Europa", "UEFA Champions League", "UEFA Champions League", "Continental", "UEFA"),
        WorldLeague("Europa", "UEFA Europa League", "UEFA Europa League", "Continental", "UEFA"),
        WorldLeague("América do Sul", "CONMEBOL Libertadores", "Copa Libertadores", "Continental", "CONMEBOL"),
        WorldLeague("América do Sul", "CONMEBOL Sudamericana", "Copa Sudamericana", "Continental", "CONMEBOL"),
        WorldLeague("Mundial", "FIFA Club World Cup", "FIFA Club World Cup", "Mundial", "FIFA")
    )

    fun countries(): List<String> = leagues.map { it.country }.distinct().sorted()
    fun divisions(country: String): List<WorldLeague> = leagues.filter { it.country == country }

    suspend fun fetchClubs(context: Context, league: WorldLeague): List<Club> {
        val prefs = context.getSharedPreferences("fm27_world_cache", Context.MODE_PRIVATE)
        val key = "clubs_${league.apiName.lowercase().replace(Regex("[^a-z0-9]"), "_")}"
        val cachedJson = prefs.getString(key, null)
        val cached = cachedJson?.let { runCatching {
            com.google.gson.Gson().fromJson<List<Club>>(it, object : TypeToken<List<Club>>() {}.type)
        }.getOrNull() }.orEmpty()
        val freshAt = prefs.getLong("${key}_at", 0L)
        if (cached.isNotEmpty() && System.currentTimeMillis() - freshAt < 7L * 24 * 60 * 60 * 1000) return cached
        val response = runCatching { api.teams(league.apiName) }.getOrNull()
        if (response == null) return cached
        val clubs = response.teams.orEmpty().mapNotNull { team ->
            val id = team.idTeam?.toIntOrNull() ?: return@mapNotNull null
            val name = team.strTeam?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            Club(
                id = id,
                name = name,
                shortName = team.strTeamShort?.take(4)?.uppercase() ?: name.take(3).uppercase(),
                strength = 65,
                stadium = team.strStadium?.takeIf { it.isNotBlank() } ?: "Estádio não informado",
                capacity = team.intStadiumCapacity?.filter { it.isDigit() }?.toIntOrNull() ?: 0,
                logoUrl = team.strBadge.orEmpty(),
                country = team.strCountry ?: league.country,
                league = team.strLeague ?: league.name
            )
        }.distinctBy { it.id }.sortedBy { it.name }
        if (clubs.isNotEmpty()) {
            prefs.edit().putString(key, com.google.gson.Gson().toJson(clubs))
                .putLong("${key}_at", System.currentTimeMillis()).apply()
            return clubs
        }
        return cached
    }

    suspend fun fetchCompetitionLogos(context: Context, country: String): List<WorldCompetition> {
        val prefs = context.getSharedPreferences("fm27_world_cache", Context.MODE_PRIVATE)
        val key = "competitions_${country.lowercase().replace(Regex("[^a-z0-9]"), "_")}"
        val cachedJson = prefs.getString(key, null)
        val cached = cachedJson?.let { runCatching {
            com.google.gson.Gson().fromJson<List<WorldCompetition>>(it, object : TypeToken<List<WorldCompetition>>() {}.type)
        }.getOrNull() }.orEmpty()
        val freshAt = prefs.getLong("${key}_at", 0L)
        if (cached.isNotEmpty() && System.currentTimeMillis() - freshAt < 7L * 24 * 60 * 60 * 1000) return cached
        val response = runCatching { api.leagues(country) }.getOrNull() ?: return cached
        val result = response.leagues.orEmpty().mapNotNull { item ->
            val id = item.idLeague ?: return@mapNotNull null
            val name = item.strLeague ?: return@mapNotNull null
            WorldCompetition(id, name, item.strCountry ?: country, item.strBadge.orEmpty(), confederationFor(country))
        }
        if (result.isNotEmpty()) prefs.edit().putString(key, com.google.gson.Gson().toJson(result))
            .putLong("${key}_at", System.currentTimeMillis()).apply()
        return result.ifEmpty { cached }
    }

    private fun confederationFor(country: String): String = when (country) {
        "Brasil", "Argentina", "Chile", "Colômbia", "Uruguai", "América do Sul" -> "CONMEBOL"
        "Japão", "Coreia do Sul", "Arábia Saudita" -> "AFC"
        "Estados Unidos", "México" -> "CONCACAF"
        "África do Sul", "Egito", "Marrocos" -> "CAF"
        "Mundial" -> "FIFA"
        else -> "UEFA"
    }
}
