package com.futebol27.manager

import kotlin.random.Random

data class PlayerAvailability(val matchesOut: Int = 0, val yellowAccumulation: Int = 0, val suspended: Boolean = false)

/** Regras simples e determinísticas por atleta para lesões e suspensões da carreira. */
object PlayerAvailabilityEngine {
    fun advanceRound(states: Map<String, PlayerAvailability>): Map<String, PlayerAvailability> =
        states.mapValues { (_, state) ->
            if (state.matchesOut > 0) state.copy(matchesOut = state.matchesOut - 1, suspended = state.suspended && state.matchesOut > 1)
            else state.copy(suspended = false)
        }.filterValues { it.matchesOut > 0 || it.yellowAccumulation > 0 || it.suspended }

    fun applyMatch(players: List<Player>, states: Map<String, PlayerAvailability>, yellowCards: Int, redCards: Int, injuries: Int, random: Random = Random.Default): Map<String, PlayerAvailability> {
        if (players.isEmpty()) return states
        val updated = states.toMutableMap()
        val booked = players.shuffled(random).take(yellowCards.coerceAtMost(players.size))
        booked.forEach { player ->
            val key = player.id.toString()
            val old = updated[key] ?: PlayerAvailability()
            val yellows = old.yellowAccumulation + 1
            updated[key] = if (yellows >= 5) PlayerAvailability(matchesOut = 1, yellowAccumulation = 0, suspended = true) else old.copy(yellowAccumulation = yellows)
        }
        players.shuffled(random).take(redCards.coerceAtMost(players.size)).forEach { player ->
            val key = player.id.toString(); val old = updated[key] ?: PlayerAvailability()
            updated[key] = old.copy(matchesOut = maxOf(old.matchesOut, 1), suspended = true)
        }
        players.shuffled(random).take(injuries.coerceAtMost(players.size)).forEach { player ->
            val key = player.id.toString(); val old = updated[key] ?: PlayerAvailability()
            updated[key] = old.copy(matchesOut = maxOf(old.matchesOut, random.nextInt(1, 4)))
        }
        return updated
    }
}
