package com.futebol27.manager

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt
import kotlin.random.Random

/** Gera jogadores fictícios reproduzíveis para o universo original do Futebol27. */
object ProceduralGenerator {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private data class Names(val country: String, val first: List<String>, val last: List<String>, val weight: Int)
    private val names = listOf(
        Names("Brasil", listOf("Caio", "Enzo", "João", "Lucas", "Mateus", "Rafael", "Vitor", "Davi", "Pedro", "Heitor", "Bruno", "Gabriel"), listOf("Almeida", "Barbosa", "Carvalho", "Costa", "Ferreira", "Lima", "Mendes", "Oliveira", "Pereira", "Ribeiro", "Santos", "Silva"), 18),
        Names("Argentina", listOf("Lautaro", "Thiago", "Mateo", "Julián", "Franco", "Nicolás", "Tomás", "Benjamín", "Facundo"), listOf("Acosta", "Álvarez", "Benítez", "Castro", "Díaz", "Fernández", "Gómez", "Herrera", "López", "Pérez", "Romero"), 10),
        Names("Espanha", listOf("Álvaro", "Hugo", "Iker", "Marco", "Pablo", "Sergio", "Adrián", "Diego", "Nico", "Raúl"), listOf("Alonso", "Blanco", "Cabrera", "Castillo", "Domínguez", "García", "Gil", "Martín", "Navarro", "Ruiz", "Torres"), 10),
        Names("Portugal", listOf("Afonso", "Diogo", "Gonçalo", "João", "Martim", "Rafael", "Tiago", "Tomás"), listOf("Alves", "Costa", "Fernandes", "Lopes", "Martins", "Pereira", "Silva", "Sousa"), 7),
        Names("França", listOf("Adam", "Enzo", "Hugo", "Mathis", "Nathan", "Noah", "Theo"), listOf("Bernard", "Dubois", "Fontaine", "Garcia", "Laurent", "Leroy", "Moreau", "Petit"), 7),
        Names("Inglaterra", listOf("Alfie", "Charlie", "Ethan", "Harry", "Jack", "Leo", "Oliver", "Theo"), listOf("Bennett", "Clarke", "Davies", "Evans", "Hughes", "Johnson", "Robinson", "Walker"), 7),
        Names("Alemanha", listOf("Ben", "Finn", "Jonas", "Leon", "Luca", "Noah", "Paul", "Tim"), listOf("Bauer", "Becker", "Fischer", "Hoffmann", "Klein", "Koch", "Schmidt", "Weber"), 6),
        Names("Itália", listOf("Andrea", "Davide", "Edoardo", "Lorenzo", "Luca", "Matteo", "Riccardo", "Tommaso"), listOf("Bianchi", "Conti", "Costa", "Esposito", "Ferrari", "Gallo", "Romano", "Russo"), 6),
        Names("Países Baixos", listOf("Bram", "Daan", "Finn", "Jesse", "Lars", "Luuk", "Sem", "Thijs"), listOf("Bakker", "Bos", "de Jong", "Jansen", "Mulder", "Visser", "de Vries", "Smit"), 4),
        Names("Uruguai", listOf("Agustín", "Bruno", "Facundo", "Felipe", "Gonzalo", "Lucas", "Martín", "Santiago"), listOf("Acosta", "Cabrera", "Olivera", "Pereira", "Rodríguez", "Silveira", "Suárez", "Vega"), 4),
        Names("Estados Unidos", listOf("Aiden", "Cameron", "Jordan", "Kai", "Liam", "Mason", "Noah", "Ryan"), listOf("Brooks", "Carter", "Davis", "Hayes", "Miller", "Parker", "Reed", "Turner"), 4),
        Names("Japão", listOf("Daichi", "Haruto", "Kaito", "Ren", "Riku", "Sota", "Yuto", "Takumi"), listOf("Ito", "Kobayashi", "Nakamura", "Sato", "Suzuki", "Tanaka", "Watanabe", "Yamamoto"), 4),
        Names("Nigéria", listOf("Chinedu", "David", "Emeka", "Ibrahim", "Kelechi", "Michael", "Samuel", "Tobi"), listOf("Adeyemi", "Balogun", "Eze", "Ibrahim", "Okafor", "Okoye", "Uche", "Yusuf"), 4),
        Names("Marrocos", listOf("Amine", "Ayoub", "Hamza", "Ilyas", "Ismael", "Mehdi", "Yassine", "Zakaria"), listOf("Amrani", "Bennani", "El Idrissi", "Fathi", "Haddad", "Naciri", "Rahimi", "Ziani"), 3),
        Names("Coreia do Sul", listOf("Do-yun", "Ji-ho", "Min-jae", "Seo-jun", "Si-woo", "Yu-jun"), listOf("Choi", "Jung", "Kang", "Kim", "Lee", "Park", "Yoon"), 2),
        Names("Suécia", listOf("Albin", "Axel", "Elias", "Hugo", "Leo", "Liam", "Noel"), listOf("Andersson", "Berg", "Johansson", "Karlsson", "Lindberg", "Lund", "Nilsson"), 2),
        Names("Croácia", listOf("Ante", "Ivan", "Josip", "Luka", "Marko", "Matej"), listOf("Babić", "Horvat", "Kovač", "Marić", "Novak", "Perić"), 2)
    )
    private val positions = listOf("GOL", "ZAG", "LAT", "VOL", "MEI", "PON", "ATA")
    private val positionWeights = listOf(10, 17, 13, 15, 17, 13, 15)

    @Synchronized
    fun generatePlayers(count: Int = 5000, seed: Int = 20261028, today: LocalDate = LocalDate.of(2026, 10, 28)): List<Player> {
        val r = Random(seed)
        val usedNames = mutableSetOf<String>()
        return (1..count.coerceAtLeast(1)).map { id ->
            val pos = choose(r, positions, positionWeights)
            val age = choose(r, (16..24).toList(), listOf(5, 9, 14, 17, 17, 14, 10, 8, 6))
            val birth = birthDate(r, age, today)
            val n = choose(r, names, names.map { it.weight })
            val first = n.first.random(r)
            var fullName = "$first ${n.last.random(r)}"
            var suffix = 2
            while (!usedNames.add(fullName.lowercase())) fullName = "$first ${n.last.random(r)} ${suffix++}"
            val ovr = overall(r, age)
            val potential = (ovr + when { age <= 17 -> r.nextInt(8, 22); age <= 19 -> r.nextInt(6, 19); age <= 21 -> r.nextInt(4, 16); else -> r.nextInt(1, 12) }).coerceIn(ovr, 92)
            val attrs = attributes(r, pos, ovr)
            val value = marketValue(ovr, potential, age)
            val salary = salary(ovr, potential, age)
            val start = today.minusDays(r.nextLong(0, 730)).format(fmt)
            val years = if (age <= 20) r.nextInt(3, 6) else if (age <= 23) r.nextInt(2, 5) else r.nextInt(1, 5)
            val end = today.plusYears(years.toLong()).plusDays(r.nextLong(0, 365)).format(fmt)
            Player(id, fullName, pos, age, ovr, birth.format(fmt), n.country, potential, value, salary, start, end, attrs)
        }
    }

    private fun birthDate(r: Random, age: Int, today: LocalDate): LocalDate {
        val earliest = today.minusYears((age + 1).toLong()).plusDays(1)
        val latest = today.minusYears(age.toLong())
        val days = java.time.temporal.ChronoUnit.DAYS.between(earliest, latest).toInt()
        return earliest.plusDays(r.nextInt(days + 1).toLong())
    }
    private fun overall(r: Random, age: Int): Int {
        val roll = r.nextDouble()
        val base = when { roll < .04 -> r.nextInt(78, 85); roll < .20 -> r.nextInt(72, 79); roll < .58 -> r.nextInt(65, 73); roll < .88 -> r.nextInt(59, 66); else -> r.nextInt(53, 60) }
        return (base + (if (age <= 17) -5 else if (age <= 19) -3 else if (age <= 21) -1 else 0) + r.nextInt(-2, 3)).coerceIn(45, 84)
    }
    private fun attributes(r: Random, pos: String, ovr: Int): PlayerAttributes {
        fun stat(bonus: Int = 0) = (ovr + bonus + r.nextInt(-13, 14)).coerceIn(25, 95)
        return when (pos) {
            "GOL" -> PlayerAttributes(stat(-10), stat(-30), stat(-5), stat(-20), stat(2), stat(-2), stat(18).coerceIn(35, 98))
            "ZAG" -> PlayerAttributes(stat(-4), stat(-22), stat(-2), stat(-8), stat(14), stat(10), 5)
            "LAT" -> PlayerAttributes(stat(10), stat(-5), stat(2), stat(4), stat(5), stat(6), 5)
            "VOL" -> PlayerAttributes(stat(-2), stat(-8), stat(7), stat(-2), stat(10), stat(7), 5)
            "MEI" -> PlayerAttributes(stat(3), stat(3), stat(12), stat(8), stat(-5), stat(-2), 5)
            "PON" -> PlayerAttributes(stat(13), stat(7), stat(1), stat(12), stat(-12), stat(0), 5)
            else -> PlayerAttributes(stat(5), stat(14), stat(-2), stat(4), stat(-14), stat(5), 5)
        }
    }
    private fun marketValue(ovr: Int, potential: Int, age: Int): Long {
        val base = when { ovr >= 80 -> 2_500_000.0; ovr >= 70 -> 350_000.0; ovr >= 60 -> 80_000.0; else -> 20_000.0 }
        val value = base * Math.pow(1.13, (ovr - 60).coerceAtLeast(0).toDouble()) * (1 + (potential - ovr).coerceAtLeast(0) * .035) * when { age <= 19 -> 1.30; age <= 22 -> 1.20; age <= 25 -> 1.05; age <= 29 -> .90; else -> .60 }
        return value.roundToInt().toLong().coerceAtLeast(10_000L)
    }
    private fun salary(ovr: Int, potential: Int, age: Int): Long {
        val value = 250.0 * Math.pow(1.18, (ovr - 50).toDouble()) * (1 + (potential - ovr).coerceAtLeast(0) * .018) * (if (age <= 20) .78 else if (age >= 31) .92 else 1.0)
        return value.roundToInt().toLong().coerceIn(150L, 250_000L)
    }
    private fun <T> choose(r: Random, values: List<T>, weights: List<Int>): T {
        var roll = r.nextInt(weights.sum())
        for (i in values.indices) { roll -= weights[i]; if (roll < 0) return values[i] }
        return values.last()
    }
}
