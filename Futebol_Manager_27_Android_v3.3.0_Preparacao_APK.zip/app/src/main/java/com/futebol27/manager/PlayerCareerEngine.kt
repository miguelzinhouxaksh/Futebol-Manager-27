package com.futebol27.manager

/** Regras locais de contratos e moral, sem dependência de rede. */
data class PlayerCareerState(
    val morale: Int = 70,
    val contractRoundsRemaining: Int = 12,
    val requestedWeeklySalary: Long = 0L,
    val unhappy: Boolean = false
) {
    val moraleLabel: String get() = when {
        morale >= 85 -> "Excelente"
        morale >= 70 -> "Boa"
        morale >= 50 -> "Regular"
        morale >= 30 -> "Baixa"
        else -> "Muito baixa"
    }
}

data class ContractOffer(val weeklySalary: Long, val rounds: Int)

data class ContractDecision(val accepted: Boolean, val state: PlayerCareerState, val message: String)

object PlayerCareerEngine {
    fun suggestedOffer(player: Player, state: PlayerCareerState): ContractOffer {
        val salary = maxOf(player.weeklySalary, state.requestedWeeklySalary)
        val moraleFactor = when {
            state.morale < 35 -> 1.20
            state.morale < 55 -> 1.10
            else -> 1.0
        }
        return ContractOffer((salary * moraleFactor).toLong(), 12)
    }

    fun decideRenewal(player: Player, state: PlayerCareerState, offer: ContractOffer): ContractDecision {
        if (offer.weeklySalary < player.weeklySalary) {
            return ContractDecision(false, state.copy(morale = (state.morale - 8).coerceAtLeast(0)), "Oferta abaixo do salário atual.")
        }
        val required = suggestedOffer(player, state).weeklySalary
        if (offer.weeklySalary < required || offer.rounds < 8) {
            return ContractDecision(false, state.copy(morale = (state.morale - 5).coerceAtLeast(0)), "O jogador recusou a proposta.")
        }
        return ContractDecision(true, state.copy(morale = (state.morale + 10).coerceAtMost(100), contractRoundsRemaining = offer.rounds, requestedWeeklySalary = offer.weeklySalary, unhappy = false), "Renovação aceita por ${offer.rounds} rodadas.")
    }

    fun applyMatchResult(state: PlayerCareerState, started: Boolean, won: Boolean): PlayerCareerState {
        val change = (if (started) 2 else -1) + (if (won) 4 else 0)
        return state.copy(morale = (state.morale + change).coerceIn(0, 100), contractRoundsRemaining = (state.contractRoundsRemaining - 1).coerceAtLeast(0))
    }

    fun effectiveOverall(overall: Int, morale: Int): Int =
        (overall + when { morale >= 85 -> 2; morale >= 70 -> 1; morale < 30 -> -3; morale < 50 -> -2; else -> 0 }).coerceIn(1, 99)
}
