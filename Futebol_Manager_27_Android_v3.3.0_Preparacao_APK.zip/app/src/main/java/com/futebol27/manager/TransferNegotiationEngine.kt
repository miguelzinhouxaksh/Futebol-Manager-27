package com.futebol27.manager

import kotlin.random.Random

data class AiTransferOffer(val playerId: Int, val clubName: String, val amount: Long, val seed: Int)

/** Regras determinísticas para negociações de compra e venda. */
object TransferNegotiationEngine {
    private val interestedClubs = listOf(
        "Atlético Nacional", "FC Utrecht", "Racing Club", "Sporting Braga",
        "Real Betis", "Fenerbahçe", "Celtic FC", "Villarreal CF",
        "Club América", "Fiorentina", "Bologna FC", "Anderlecht"
    )

    fun openingOffer(player: Player): Long = (player.marketValue * 0.80).toLong().coerceAtLeast(1L)
    fun counterOffer(player: Player): Long = (player.marketValue * 1.10).toLong().coerceAtLeast(openingOffer(player))
    fun acceptsCounter(player: Player, requestedFee: Long): Boolean =
        requestedFee > 0L && requestedFee <= (player.marketValue * 1.15).toLong()
    fun saleRevenue(player: Player, agreedFee: Long): Long =
        agreedFee.coerceIn(1L, (player.marketValue * 1.5).toLong().coerceAtLeast(1L))

    /** Oferta estável por carreira, temporada, rodada e jogador. */
    fun generateAiOffer(player: Player, userClubId: Int, season: Int, round: Int): AiTransferOffer {
        val seed = 31 * (31 * (31 * userClubId + season) + round) + player.id
        val random = Random(seed)
        val club = interestedClubs[random.nextInt(interestedClubs.size)]
        val minimum = 0.78
        val maximum = if (player.age <= 23) 1.08 else 1.02
        val multiplier = minimum + random.nextDouble() * (maximum - minimum)
        return AiTransferOffer(player.id, club, (player.marketValue * multiplier).toLong().coerceAtLeast(1L), seed)
    }

    fun askingPrice(player: Player): Long = (player.marketValue * 1.25).toLong().coerceAtLeast(1L)
    fun acceptsPurchaseOffer(player: Player, offer: Long): Boolean =
        offer >= (player.marketValue * 1.10).toLong().coerceAtLeast(1L) && offer <= askingPrice(player)
    fun purchaseFee(player: Player, offer: Long): Long =
        offer.coerceIn((player.marketValue * 1.10).toLong().coerceAtLeast(1L), askingPrice(player))
}
