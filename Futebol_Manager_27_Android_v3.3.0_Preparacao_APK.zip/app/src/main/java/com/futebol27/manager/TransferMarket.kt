package com.futebol27.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val MarketBg = Color(0xFF070A10)
private val MarketPanel = Color(0xFF121824)
private val MarketLime = Color(0xFFC5FF36)
private val MarketMuted = Color(0xFF8D98AA)

@Composable
fun TransferMarketScreen(
    club: Club,
    budget: Long,
    signedIds: Set<String>,
    onSign: (Player, Long) -> Unit,
    onSell: (Player, Long) -> Unit,
    onLoan: (Player, Int, Long, String) -> Unit = { _, _, _, _ -> },
    onLoanOut: (Player, Int, Int, String) -> Unit = { _, _, _, _ -> },
    loanedIds: Set<String> = emptySet(),
    loanedOutIds: Set<String> = emptySet(),
    outgoingLoans: Map<String, OutgoingLoanContract> = emptyMap(),
    season: Int = 1,
    round: Int = 1
) {
    val candidates = remember(club.id) {
        ProceduralGenerator.generatePlayers(count = 5000, seed = 20261028 + club.id)
            .drop(25).filter { it.age <= 29 && it.overall >= 58 }
            .take(60)
    }
    var query by remember { mutableStateOf("") }
    var position by remember { mutableStateOf("TODAS") }
    var negotiatingPlayer by remember { mutableStateOf<Player?>(null) }
    var negotiationMessage by remember { mutableStateOf("") }
    var purchasePlayer by remember { mutableStateOf<Player?>(null) }
    var purchaseOfferText by remember { mutableStateOf("") }
    var purchaseMessage by remember { mutableStateOf("") }
    var loanPlayer by remember { mutableStateOf<Player?>(null) }
    var loanDuration by remember { mutableIntStateOf(LoanEngine.DEFAULT_DURATION_ROUNDS) }
    var loanOutPlayer by remember { mutableStateOf<Player?>(null) }
    var loanOutDuration by remember { mutableIntStateOf(LoanEngine.DEFAULT_DURATION_ROUNDS) }
    val available = remember(candidates, signedIds, query, position) {
        candidates.filter { player ->
            player.id.toString() !in signedIds &&
                (query.isBlank() || player.name.contains(query, true) || player.nationality.contains(query, true)) &&
                (position == "TODAS" || player.position == position)
        }
    }
    val signed = candidates.filter { it.id.toString() in signedIds && it.id.toString() !in loanedIds }
    val loanedOut = signed.filter { it.id.toString() in loanedOutIds }
    val availableForSale = signed.filter { it.id.toString() !in loanedOutIds }
    val loaned = candidates.filter { it.id.toString() in loanedIds }
    val aiOffers = remember(availableForSale, club.id, season, round) {
        availableForSale.associate { it.id to TransferNegotiationEngine.generateAiOffer(it, club.id, season, round) }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MarketBg),
        contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item {
            Text("MERCADO DE TRANSFERÊNCIAS", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
            Text("Contrate jogadores fictícios para ${club.name}", color = MarketMuted, fontSize = 11.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MarketPanel)) {
                Column(Modifier.fillMaxWidth().padding(13.dp)) {
                    Text("ORÇAMENTO DISPONÍVEL", color = MarketMuted, fontSize = 10.sp)
                    Text("€ ${"%,d".format(budget)}", color = MarketLime, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("Taxa estimada: valor de mercado + 25% • salário semanal informado no perfil", color = MarketMuted, fontSize = 9.sp)
                }
            }
        }
        if (loaned.isNotEmpty()) item {
            Text("JOGADORES EMPRESTADOS (${loaned.size})", color = MarketLime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        items(loaned, key = { "loan-${it.id}" }) { player ->
            PlayerMarketCard(player, "EMPRÉSTIMO ATIVO", onAction = null)
        }
        if (loanedOut.isNotEmpty()) item {
            Text("EMPRESTADOS A OUTROS CLUBES (${loanedOut.size})", color = MarketLime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        items(loanedOut, key = { "out-${it.id}" }) { player ->
            val contract = outgoingLoans[player.id.toString()]
            PlayerMarketCard(player, "CEDIDO • ${contract?.roundsRemaining ?: 0} RODADAS", onAction = null)
            Text("${contract?.borrowerClub ?: "Clube parceiro"} • recebe € ${"%,d".format(contract?.weeklyWageContribution ?: 0L)}/semana", color = MarketMuted, fontSize = 9.sp)
        }
        if (availableForSale.isNotEmpty()) item {
            Text("CONTRATAÇÕES DESTA CARREIRA (${availableForSale.size})", color = MarketLime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        items(availableForSale, key = { "signed-${it.id}" }) { player ->
            val offer = aiOffers[player.id]
            PlayerMarketCard(player, if (offer != null) "OFERTA € ${"%,d".format(offer.amount)}" else "SEM OFERTA",
                onAction = { negotiatingPlayer = player; negotiationMessage = "" },
                secondaryLabel = "CEDER",
                onSecondaryAction = { loanOutPlayer = player; loanOutDuration = LoanEngine.DEFAULT_DURATION_ROUNDS })
            if (offer != null) Text("Interesse de ${offer.clubName} • proposta válida nesta rodada", color = MarketMuted, fontSize = 9.sp)
        }
        item {
            Text("JOGADORES DISPONÍVEIS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar jogador ou país") }, singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MarketLime, unfocusedBorderColor = Color(0xFF30394A), focusedTextColor = Color.White, unfocusedTextColor = Color.White))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("TODAS", "GOL", "ZAG", "LAT", "VOL", "MEI", "PON", "ATA").forEach { pos ->
                    FilterChip(selected = position == pos, onClick = { position = pos }, label = { Text(pos, fontSize = 9.sp) })
                }
            }
            Text("${available.size} opções encontradas", color = MarketMuted, fontSize = 10.sp)
        }
        items(available, key = { it.id }) { player ->
            val fee = TransferNegotiationEngine.askingPrice(player)
            PlayerMarketCard(
                player,
                if (fee <= budget) "NEGOCIAR • € ${"%,d".format(fee)}" else "NEGOCIAR VALOR",
                onAction = {
                    purchasePlayer = player
                    purchaseOfferText = TransferNegotiationEngine.counterOffer(player).toString()
                    purchaseMessage = ""
                },
                secondaryLabel = "EMPRÉSTIMO",
                onSecondaryAction = { loanPlayer = player; loanDuration = LoanEngine.DEFAULT_DURATION_ROUNDS }
            )
        }
        item { Text("As propostas são simuladas por clubes do universo do jogo. Valores finais dependem da negociação.", color = MarketMuted, fontSize = 9.sp) }
    }
    purchasePlayer?.let { player ->
        val offer = purchaseOfferText.toLongOrNull() ?: 0L
        val accepted = TransferNegotiationEngine.acceptsPurchaseOffer(player, offer)
        val fee = if (accepted) TransferNegotiationEngine.purchaseFee(player, offer) else 0L
        AlertDialog(
            onDismissRequest = { purchasePlayer = null },
            title = { Text("Negociar ${player.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Valor de mercado: € ${"%,d".format(player.marketValue)}")
                    Text("Pedido do clube: € ${"%,d".format(TransferNegotiationEngine.askingPrice(player))}")
                    OutlinedTextField(
                        value = purchaseOfferText,
                        onValueChange = { purchaseOfferText = it.filter(Char::isDigit) },
                        label = { Text("Sua oferta (€)") },
                        singleLine = true
                    )
                    if (purchaseMessage.isNotBlank()) Text(purchaseMessage, color = MarketLime)
                    if (accepted && fee > budget) Text("Oferta aceita, mas falta orçamento. Disponível: € ${"%,d".format(budget)}", color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    when {
                        offer <= 0L -> purchaseMessage = "Digite um valor válido."
                        !accepted -> purchaseMessage = "O clube recusou. Ofereça pelo menos 110% do valor de mercado."
                        fee > budget -> purchaseMessage = "Orçamento insuficiente para concluir a contratação."
                        else -> {
                            onSign(player, fee)
                            purchasePlayer = null
                        }
                    }
                }) { Text("ENVIAR OFERTA") }
            },
            dismissButton = { TextButton(onClick = { purchasePlayer = null }) { Text("CANCELAR") } }
        )
    }
    loanPlayer?.let { player ->
        val weeklyCost = LoanEngine.weeklyCost(player)
        AlertDialog(
            onDismissRequest = { loanPlayer = null },
            title = { Text("Empréstimo de ${player.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Clube de origem: ${player.nationality} (clube parceiro fictício)")
                    Text("Duração: $loanDuration rodadas")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(8, 12, 16, 24).forEach { duration ->
                            FilterChip(selected = loanDuration == duration, onClick = { loanDuration = duration }, label = { Text("$duration") })
                        }
                    }
                    Text("Sua parte do salário: € ${"%,d".format(weeklyCost)}/semana")
                    Text("Sem taxa de transferência. O atleta retorna automaticamente ao fim do prazo.", color = MarketMuted, fontSize = 10.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onLoan(player, loanDuration, weeklyCost, "Clube parceiro")
                    loanPlayer = null
                }) { Text("CONFIRMAR EMPRÉSTIMO") }
            },
            dismissButton = { TextButton(onClick = { loanPlayer = null }) { Text("CANCELAR") } }
        )
    }
    loanOutPlayer?.let { player ->
        val contribution = player.weeklySalary / 2L
        AlertDialog(
            onDismissRequest = { loanOutPlayer = null },
            title = { Text("Emprestar ${player.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Clube interessado: Clube parceiro")
                    Text("Duração: $loanOutDuration rodadas")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(8, 12, 16, 24).forEach { duration ->
                            FilterChip(selected = loanOutDuration == duration, onClick = { loanOutDuration = duration }, label = { Text("$duration") })
                        }
                    }
                    Text("Contribuição salarial recebida: € ${"%,d".format(contribution)}/semana", color = MarketLime)
                    Text("O jogador fica indisponível para escalação e retorna automaticamente ao fim do prazo.", color = MarketMuted, fontSize = 10.sp)
                }
            },
            confirmButton = { TextButton(onClick = { onLoanOut(player, loanOutDuration, 50, "Clube parceiro"); loanOutPlayer = null }) { Text("CONFIRMAR CESSÃO") } },
            dismissButton = { TextButton(onClick = { loanOutPlayer = null }) { Text("CANCELAR") } }
        )
    }
    negotiatingPlayer?.let { player ->
        val aiOffer = aiOffers[player.id] ?: TransferNegotiationEngine.generateAiOffer(player, club.id, season, round)
        val offer = aiOffer.amount
        val counter = TransferNegotiationEngine.counterOffer(player)
        AlertDialog(
            onDismissRequest = { negotiatingPlayer = null },
            title = { Text("Proposta por ${player.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${aiOffer.clubName} apresentou uma proposta pelo jogador.")
                    Text("Valor de mercado: € ${"%,d".format(player.marketValue)}")
                    Text("Oferta inicial: € ${"%,d".format(offer)}", color = MarketMuted)
                    Text("Sua contraproposta: € ${"%,d".format(counter)}", color = MarketLime, fontWeight = FontWeight.Bold)
                    if (negotiationMessage.isNotBlank()) Text(negotiationMessage, color = MarketLime)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onSell(player, TransferNegotiationEngine.saleRevenue(player, offer))
                    negotiatingPlayer = null
                }) { Text("ACEITAR OFERTA") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        if (TransferNegotiationEngine.acceptsCounter(player, counter)) {
                            onSell(player, TransferNegotiationEngine.saleRevenue(player, counter))
                            negotiatingPlayer = null
                        } else negotiationMessage = "O clube recusou a contraproposta."
                    }) { Text("CONTRAPROPOSTA") }
                    TextButton(onClick = { negotiatingPlayer = null }) { Text("FECHAR") }
                }
            }
        )
    }
}

@Composable
private fun PlayerMarketCard(
    player: Player,
    actionLabel: String?,
    onAction: (() -> Unit)? = null,
    secondaryLabel: String? = null,
    onSecondaryAction: (() -> Unit)? = null
) {
    Card(colors = CardDefaults.cardColors(containerColor = MarketPanel), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(player.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("${player.position} • ${player.age} anos • ${player.nationality}", color = MarketMuted, fontSize = 10.sp)
                Text("OVR ${player.overall} • Pot. ${player.potential} • Valor € ${"%,d".format(player.marketValue)}", color = MarketMuted, fontSize = 9.sp)
                Text("Salário: € ${"%,d".format(player.weeklySalary)}/semana", color = MarketMuted, fontSize = 9.sp)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${player.overall}", color = MarketLime, fontSize = 19.sp, fontWeight = FontWeight.Black)
                if (actionLabel != null) Button(onClick = { onAction?.invoke() }, enabled = onAction != null && !actionLabel.startsWith("ORÇAMENTO"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), colors = ButtonDefaults.buttonColors(containerColor = MarketLime, contentColor = MarketBg)) {
                    Text(actionLabel, fontSize = 9.sp, maxLines = 1)
                }
                if (secondaryLabel != null) OutlinedButton(onClick = { onSecondaryAction?.invoke() },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
                    Text(secondaryLabel, fontSize = 8.sp, maxLines = 1)
                }
            }
        }
    }
}
