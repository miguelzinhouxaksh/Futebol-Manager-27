package com.futebol27.manager

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

private val Bg = Color(0xFF070A10)
private val Panel = Color(0xFF121824)
private val Panel2 = Color(0xFF171F2D)
private val Lime = Color(0xFFC5FF36)
private val Muted = Color(0xFF8D98AA)
private val Green = Color(0xFF37D995)
private val Red = Color(0xFFB92332)

@Composable
fun Futebol27App() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("futebol_manager_27", android.content.Context.MODE_PRIVATE) }
    var careerStarted by remember { mutableStateOf(prefs.getBoolean("career_started", false)) }
    var selectedDivision by remember { mutableStateOf(prefs.getString("division", "Brasileirão Série A") ?: "Brasileirão Série A") }
    var selectedClubName by remember { mutableStateOf(prefs.getString("club_name", "Athletic Club") ?: "Athletic Club") }
    var selectedClub by remember { mutableStateOf(Club(
        prefs.getInt("club_id", 1), selectedClubName, prefs.getString("club_short", "ATH") ?: "ATH",
        prefs.getInt("club_strength", 78), prefs.getString("club_stadium", "San Mamés") ?: "San Mamés",
        prefs.getInt("club_capacity", 53289), prefs.getString("club_logo", "") ?: "",
        prefs.getString("club_country", "Espanha") ?: "Espanha", selectedDivision
    )) }
    if (!careerStarted) {
        CareerSetupScreen(
            initialDivision = selectedDivision,
            initialClub = selectedClubName,
            onStart = { division, club ->
                selectedDivision = division
                selectedClubName = club.name
                selectedClub = club
                prefs.edit().putString("division", division).putString("club_name", club.name)
                    .putInt("club_id", club.id).putString("club_short", club.shortName)
                    .putInt("club_strength", club.strength).putString("club_stadium", club.stadium)
                    .putInt("club_capacity", club.capacity).putString("club_logo", club.logoUrl)
                    .putString("club_country", club.country).putString("club_league", club.league).putBoolean("career_started", true).apply()
                careerStarted = true
            }
        )
        return
    }
    var page by remember { mutableStateOf("Início") }
    var round by remember { mutableIntStateOf(prefs.getInt("round", 1)) }
    var season by remember { mutableIntStateOf(prefs.getInt("season", 1)) }
    var lastSeasonSummary by remember(selectedClub.id) { mutableStateOf(prefs.getString("last_season_summary_${selectedClub.id}", "") ?: "") }
    var played by remember { mutableIntStateOf(prefs.getInt("played", 0)) }
    var points by remember { mutableIntStateOf(prefs.getInt("points", 0)) }
    var balance by remember { mutableLongStateOf(prefs.getLong("balance", 4_700_000L)) }
    var transferBudget by remember { mutableLongStateOf(prefs.getLong("transfer_budget", 1_200_000L)) }
    var seasonRevenue by remember { mutableLongStateOf(prefs.getLong("season_revenue", 0L)) }
    var signedPlayerIds by remember { mutableStateOf(prefs.getStringSet("signed_player_ids_${selectedClub.id}", emptySet())?.toSet() ?: emptySet()) }
    var formation by remember(selectedClub.id) { mutableStateOf(prefs.getString("formation_${selectedClub.id}", "4-3-3") ?: "4-3-3") }
    var startingIds by remember(selectedClub.id) { mutableStateOf(prefs.getStringSet("starting_xi_${selectedClub.id}", emptySet())?.toSet() ?: emptySet()) }
    val gson = remember { Gson() }
    val loanContractType = remember { object : TypeToken<Map<String, LoanContract>>() {}.type }
    var loanContracts by remember(selectedClub.id) {
        mutableStateOf(runCatching {
            gson.fromJson<Map<String, LoanContract>>(prefs.getString("loan_contracts_${selectedClub.id}", "{}"), loanContractType) ?: emptyMap()
        }.getOrDefault(emptyMap()))
    }
    val outgoingLoanType = remember { object : TypeToken<Map<String, OutgoingLoanContract>>() {}.type }
    var outgoingLoans by remember(selectedClub.id) {
        mutableStateOf(runCatching {
            gson.fromJson<Map<String, OutgoingLoanContract>>(prefs.getString("outgoing_loans_${selectedClub.id}", "{}"), outgoingLoanType) ?: emptyMap()
        }.getOrDefault(emptyMap()))
    }
    val trainingType = remember { object : TypeToken<Map<String, Int>>() {}.type }
    val availabilityType = remember { object : TypeToken<Map<String, PlayerAvailability>>() {}.type }
    val fatigueType = remember { object : TypeToken<Map<String, Int>>() {}.type }
    var playerFatigue by remember(selectedClub.id) {
        mutableStateOf(runCatching { gson.fromJson<Map<String, Int>>(prefs.getString("fatigue_${selectedClub.id}", "{}"), fatigueType) ?: emptyMap() }.getOrDefault(emptyMap()))
    }
    var playerAvailability by remember(selectedClub.id) {
        mutableStateOf(runCatching { gson.fromJson<Map<String, PlayerAvailability>>(prefs.getString("availability_${selectedClub.id}", "{}"), availabilityType) ?: emptyMap() }.getOrDefault(emptyMap()))
    }
    var trainingXp by remember(selectedClub.id) {
        mutableStateOf(runCatching { gson.fromJson<Map<String, Int>>(prefs.getString("training_xp_${selectedClub.id}", "{}"), trainingType) ?: emptyMap() }.getOrDefault(emptyMap()))
    }
    val careerStateType = remember { object : TypeToken<Map<String, PlayerCareerState>>() {}.type }
    var playerCareerStates by remember(selectedClub.id) {
        mutableStateOf(runCatching {
            gson.fromJson<Map<String, PlayerCareerState>>(prefs.getString("player_career_${selectedClub.id}", "{}"), careerStateType) ?: emptyMap()
        }.getOrDefault(emptyMap()))
    }
    val careerPlayers = remember(selectedClub.id, signedPlayerIds, trainingXp, loanContracts, outgoingLoans) {
        val pool = ProceduralGenerator.generatePlayers(count = 5000, seed = 20261028 + selectedClub.id)
        (pool.take(25) + pool.drop(25).filter { it.id.toString() in signedPlayerIds }).distinctBy { it.id }
            .filter { it.id.toString() !in outgoingLoans.keys }
            .map { p -> p.copy(overall = (p.overall + (trainingXp["grown_${p.id}"] ?: 0)).coerceAtMost(p.potential)) }
    }
    fun persistCareerStates(next: Map<String, PlayerCareerState>) {
        playerCareerStates = next
        prefs.edit().putString("player_career_${selectedClub.id}", gson.toJson(next))
            .putLong("last_autosave", System.currentTimeMillis()).apply()
    }
    var lastResult by remember {
        mutableStateOf(
            if (prefs.getBoolean("has_last_result", false)) FixtureResult(
                prefs.getString("last_home", "") ?: "",
                prefs.getString("last_away", "") ?: "",
                prefs.getInt("last_home_goals", 0), prefs.getInt("last_away_goals", 0),
                prefs.getInt("last_possession", 50), prefs.getInt("last_shots_home", 0),
                prefs.getInt("last_shots_away", 0), prefs.getInt("last_yellows", 0),
                prefs.getString("last_summary", "") ?: "",
                prefs.getInt("last_red_cards", 0), prefs.getInt("last_injuries", 0)
            ) else null
        )
    }
    var showMatch by remember { mutableStateOf(false) }
    val clubPool = ClubCatalog.clubsFor(selectedDivision)
    val home = selectedClub
    // Garante que o clube escolhido participe do campeonato e constrói calendário real de turno/returno.
    val leagueClubs = remember(selectedDivision, selectedClub.id) {
        (listOf(selectedClub) + clubPool).distinctBy { it.id }
    }
    val leagueFixtures = remember(leagueClubs) { LeagueEngine.createDoubleRoundRobin(leagueClubs) }
    val currentFixture = leagueFixtures.firstOrNull { it.round == round && (it.homeClubId == home.id || it.awayClubId == home.id) }
        ?: leagueFixtures.first()
    val fixtureHome = leagueClubs.first { it.id == currentFixture.homeClubId }
    val fixtureAway = leagueClubs.first { it.id == currentFixture.awayClubId }
    val resultsType = remember { object : TypeToken<List<RecordedFixtureResult>>() {}.type }
    var leagueResults by remember(selectedDivision, selectedClub.id) {
        mutableStateOf(
            runCatching {
                gson.fromJson<List<RecordedFixtureResult>>(
                    prefs.getString("league_results_${selectedDivision}_${selectedClub.id}", "[]"), resultsType
                ) ?: emptyList()
            }.getOrDefault(emptyList())
        )
    }
    val away = if (fixtureHome.id == home.id) fixtureAway else fixtureHome
    fun playMatch() {
        // Evita registrar duas vezes o mesmo confronto caso o estado local seja restaurado.
        if (leagueResults.any { it.fixtureId == currentFixture.id }) return
        val careerPool = ProceduralGenerator.generatePlayers(count = 5000, seed = 20261028 + selectedClub.id)
        val careerRoster = (careerPool.take(25) + careerPool.drop(25).filter { it.id.toString() in signedPlayerIds })
            .filter { it.id.toString() !in outgoingLoans.keys }
        val eligibleRoster = careerRoster.filter { (playerAvailability[it.id.toString()]?.matchesOut ?: 0) == 0 && playerAvailability[it.id.toString()]?.suspended != true }
        val recoveredFatigue = MatchSquadManager.recoverBetweenRounds(playerFatigue)
        val squadPlan = MatchSquadManager.prepare(eligibleRoster, startingIds, recoveredFatigue, round)
        val effectiveLineup = squadPlan.finalLineup.ifEmpty { eligibleRoster.sortedByDescending { it.overall }.take(11) }
        val lineupAverage = squadPlan.effectiveOverall.takeIf { effectiveLineup.isNotEmpty() } ?: selectedClub.strength
        playerFatigue = squadPlan.fatigueAfterMatch
        prefs.edit().putString("fatigue_${selectedClub.id}", gson.toJson(playerFatigue)).apply()
        val rawResult = if (fixtureHome.id == selectedClub.id) {
            MatchEngine.simulate(fixtureHome, fixtureAway, homeFormation = formation, homeLineupOverall = lineupAverage)
        } else {
            MatchEngine.simulate(fixtureHome, fixtureAway)
        }
        val substitutionText = if (squadPlan.substitutions.isEmpty()) "Sem substituições automáticas." else
            "Substituições: " + squadPlan.substitutions.joinToString { (outgoing, incoming) -> "${outgoing.name} saiu; ${incoming.name} entrou" } + "."
        val result = rawResult.copy(summary = rawResult.summary + " " + substitutionText)
        playerAvailability = PlayerAvailabilityEngine.advanceRound(playerAvailability)
        val advancedLoans = LoanEngine.advanceRound(loanContracts)
        val returnedLoans = LoanEngine.returnedPlayerIds(loanContracts, advancedLoans)
        if (returnedLoans.isNotEmpty()) {
            signedPlayerIds = signedPlayerIds - returnedLoans
        }
        loanContracts = advancedLoans
        val advancedOutgoingLoans = OutgoingLoanEngine.advanceRound(outgoingLoans)
        outgoingLoans = advancedOutgoingLoans
        prefs.edit().putStringSet("signed_player_ids_${selectedClub.id}", signedPlayerIds)
            .putString("loan_contracts_${selectedClub.id}", gson.toJson(loanContracts))
            .putString("outgoing_loans_${selectedClub.id}", gson.toJson(outgoingLoans)).apply()
        playerAvailability = PlayerAvailabilityEngine.applyMatch(
            effectiveLineup, playerAvailability, result.yellowCards, result.redCards, result.injuries
        )
        prefs.edit().putString("availability_${selectedClub.id}", gson.toJson(playerAvailability)).apply()
        lastResult = result
        // Todos os jogos da rodada são concluídos: o campeonato não fica com os rivais parados.
        leagueResults = LeagueEngine.completeRound(
            fixtures = leagueFixtures,
            existingResults = leagueResults,
            round = round,
            userFixtureId = currentFixture.id,
            userHomeGoals = result.homeGoals,
            userAwayGoals = result.awayGoals
        ) { fixture ->
            val aiHome = leagueClubs.first { it.id == fixture.homeClubId }
            val aiAway = leagueClubs.first { it.id == fixture.awayClubId }
            val seed = selectedClub.id * 100_000 + season * 1_000 + round * 100 + fixture.id
            val aiResult = MatchEngine.simulate(aiHome, aiAway, random = kotlin.random.Random(seed))
            RecordedFixtureResult(fixture.id, aiResult.homeGoals, aiResult.awayGoals)
        }
        prefs.edit().putString("league_results_${selectedDivision}_${selectedClub.id}", gson.toJson(leagueResults)).apply()
        result.let {
            prefs.edit().putBoolean("has_last_result", true)
                .putString("last_home", it.home).putString("last_away", it.away)
                .putInt("last_home_goals", it.homeGoals).putInt("last_away_goals", it.awayGoals)
                .putInt("last_possession", it.possessionHome)
                .putInt("last_shots_home", it.shotsHome).putInt("last_shots_away", it.shotsAway)
                .putInt("last_yellows", it.yellowCards).putString("last_summary", it.summary)
                .putInt("last_red_cards", it.redCards).putInt("last_injuries", it.injuries).apply()
        }
        val userWon = if (fixtureHome.id == home.id) result.homeGoals > result.awayGoals else result.awayGoals > result.homeGoals
        val draw = result.homeGoals == result.awayGoals
        val selectedIds = effectiveLineup.map { it.id.toString() }.toSet()
        val moraleUpdated = careerPlayers.associate { player ->
            val key = player.id.toString()
            val state = playerCareerStates[key] ?: PlayerCareerState()
            key to PlayerCareerEngine.applyMatchResult(state, key in selectedIds, userWon)
        }
        persistCareerStates(moraleUpdated)
        round += 1
        played += 1
        points += if (userWon) 3 else if (draw) 1 else 0
        val seasonFinished = round > (leagueFixtures.maxOfOrNull { it.round } ?: 1)
        if (seasonFinished) {
            // Guarda um resumo simples antes de iniciar uma nova temporada.
            val finalPosition = LeagueEngine.standings(leagueClubs, leagueFixtures, leagueResults)
                .indexOfFirst { it.clubName == selectedClub.name } + 1
            lastSeasonSummary = "Temporada $season • ${finalPosition.coerceAtLeast(1)}º lugar • $points pontos • $played jogos"
            val historyKey = "season_history_${selectedClub.id}"
            val previousHistory = prefs.getString(historyKey, "") ?: ""
            val updatedHistory = (listOf(lastSeasonSummary) + previousHistory.lines().filter { it.isNotBlank() }).take(10).joinToString("\n")
            prefs.edit().putString("last_season_summary_${selectedClub.id}", lastSeasonSummary)
                .putString(historyKey, updatedHistory).apply()
            season += 1
            round = 1
            played = 0
            points = 0
            seasonRevenue = 0L
            leagueResults = emptyList()
            prefs.edit().putString("league_results_${selectedDivision}_${selectedClub.id}", "[]").apply()
        }
        val attendance = (home.capacity * (0.52 + home.strength / 250.0)).toLong().coerceAtMost(home.capacity.toLong())
        val gateIncome = attendance * 18L
        val commercialIncome = 85_000L
        val wagePool = ProceduralGenerator.generatePlayers(count = 5000, seed = 20261028 + selectedClub.id)
        val wageRoster = (wagePool.take(25) + wagePool.drop(25).filter { it.id.toString() in signedPlayerIds }).distinctBy { it.id }
        val weeklyWages = wageRoster.sumOf { player ->
            val key = player.id.toString()
            if (key in outgoingLoans) OutgoingLoanEngine.netWeeklyWage(player, outgoingLoans[key])
            else loanContracts[key]?.weeklyWageShare
                ?: (playerCareerStates[key]?.requestedWeeklySalary ?: 0L).takeIf { it > 0L }
                ?: player.weeklySalary
        }
        balance = (balance + gateIncome + commercialIncome - weeklyWages).coerceAtLeast(0L)
        seasonRevenue += gateIncome + commercialIncome
        prefs.edit().putInt("round", round).putInt("season", season).putInt("played", played).putInt("points", points)
            .putLong("balance", balance).putLong("transfer_budget", transferBudget)
            .putLong("season_revenue", seasonRevenue)
            .putLong("last_autosave", System.currentTimeMillis()).apply()
        showMatch = true
    }
    Row(Modifier.fillMaxSize().background(Bg)) {
        NavigationRail(containerColor = Color(0xFF090D14), contentColor = Muted,
            header = { Text("F27", color = Lime, fontSize = 23.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 16.dp)) }) {
            listOf("Início" to Icons.Default.Home, "Elenco" to Icons.Default.Groups, "Tática" to Icons.Default.SportsSoccer, "Treino" to Icons.Default.FitnessCenter,
                "Competições" to Icons.Default.EmojiEvents, "Calendário" to Icons.Default.CalendarMonth,
                "Finanças" to Icons.Default.AccountBalanceWallet, "Contratos" to Icons.Default.Description, "Transferências" to Icons.Default.SwapHoriz).forEach { (label, icon) ->
                NavigationRailItem(selected = page == label, onClick = { page = label },
                    icon = { Icon(icon, contentDescription = label) }, label = { Text(label, fontSize = 9.sp) },
                    alwaysShowLabel = false, colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = Lime, selectedTextColor = Lime,
                        indicatorColor = Color(0xFF26331B), unselectedIconColor = Muted))
            }
        }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF0A0E15)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("FUTEBOL MANAGER 27", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Text("$selectedDivision • Universo real", color = Muted, fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(page.uppercase(), color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("TEMPORADA $season • JOGOS $played", color = Muted, fontSize = 10.sp)
                }
            }
            HorizontalDivider(color = Color(0xFF202735))
            when (page) {
                "Elenco" -> SquadScreen(selectedClub, signedPlayerIds, playerAvailability)
                "Tática" -> TacticsScreen(selectedClub, signedPlayerIds, formation, startingIds,
                    onFormation = { formation = it; prefs.edit().putString("formation_${selectedClub.id}", it).apply() },
                    onStarting = { startingIds = it; prefs.edit().putStringSet("starting_xi_${selectedClub.id}", it).apply() })
                "Treino" -> TrainingScreen(selectedClub, signedPlayerIds, trainingXp, balance,
                    onTrain = { player ->
                        if (balance < TrainingEngine.SESSION_COST) false else {
                            val (xp, growth) = TrainingEngine.train(player, trainingXp[player.id.toString()] ?: 0)
                            if (player.overall >= player.potential) false else {
                                trainingXp = trainingXp + (player.id.toString() to xp)
                                if (growth > 0) trainingXp = trainingXp + ("grown_${player.id}" to ((trainingXp["grown_${player.id}"] ?: 0) + growth))
                                balance -= TrainingEngine.SESSION_COST
                                prefs.edit().putString("training_xp_${selectedClub.id}", gson.toJson(trainingXp)).putLong("balance", balance).apply()
                                true
                            }
                        }
                    })
                "Contratos" -> ContractsScreen(selectedClub, careerPlayers, playerCareerStates, balance) { player, offer ->
                    val key = player.id.toString()
                    val state = playerCareerStates[key] ?: PlayerCareerState()
                    val decision = PlayerCareerEngine.decideRenewal(player, state, offer)
                    val next = playerCareerStates + (key to decision.state)
                    persistCareerStates(next)
                    if (decision.accepted) {
                        prefs.edit().putLong("last_autosave", System.currentTimeMillis()).apply()
                    }
                    decision.message
                }
                "Transferências" -> TransferMarketScreen(selectedClub, transferBudget, signedPlayerIds,
                    onLoan = { player, duration, weeklyCost, parentClub ->
                        val id = player.id.toString()
                        loanContracts = loanContracts + (id to LoanEngine.createContract(player, duration, parentClub))
                        signedPlayerIds = signedPlayerIds + id
                        prefs.edit().putStringSet("signed_player_ids_${selectedClub.id}", signedPlayerIds)
                            .putString("loan_contracts_${selectedClub.id}", gson.toJson(loanContracts))
                            .putLong("last_autosave", System.currentTimeMillis()).apply()
                    },
                    loanedIds = loanContracts.keys,
                    loanedOutIds = outgoingLoans.keys,
                    outgoingLoans = outgoingLoans,
                    onLoanOut = { player, duration, contributionPercent, borrower ->
                        val key = player.id.toString()
                        outgoingLoans = outgoingLoans + (key to OutgoingLoanEngine.createContract(player, borrower, duration, contributionPercent))
                        prefs.edit().putString("outgoing_loans_${selectedClub.id}", gson.toJson(outgoingLoans))
                            .putLong("last_autosave", System.currentTimeMillis()).apply()
                    },
                    season = season, round = round,
                    onSign = { player, fee ->
                        signedPlayerIds = signedPlayerIds + player.id.toString()
                        transferBudget = (transferBudget - fee).coerceAtLeast(0L)
                        balance = (balance - fee).coerceAtLeast(0L)
                        prefs.edit().putStringSet("signed_player_ids_${selectedClub.id}", signedPlayerIds)
                            .putLong("transfer_budget", transferBudget).putLong("balance", balance).apply()
                    },
                    onSell = { player, fee ->
                        signedPlayerIds = signedPlayerIds - player.id.toString()
                        transferBudget += fee
                        balance += fee
                        prefs.edit().putStringSet("signed_player_ids_${selectedClub.id}", signedPlayerIds)
                            .putLong("transfer_budget", transferBudget).putLong("balance", balance).apply()
                    })
                "Competições" -> CompetitionsScreen(round, points, played, selectedClub.country, leagueClubs, leagueFixtures, leagueResults)
                "Calendário" -> CalendarScreen(round, lastResult, fixtureHome, fixtureAway, ::playMatch)
                "Finanças" -> FinanceScreen(balance, transferBudget, seasonRevenue, onBudgetChange = { transferBudget = it; prefs.edit().putLong("transfer_budget", it).apply() })
                else -> Dashboard(round, season, points, played, lastSeasonSummary, lastResult, home, selectedDivision, ::playMatch, { page = "Elenco" }, { page = "Competições" })
            }
        }
    }
    if (showMatch && lastResult != null) MatchResultDialog(lastResult!!) { showMatch = false }
}

@Composable
private fun CareerSetupScreen(
    initialDivision: String,
    initialClub: String,
    onStart: (String, Club) -> Unit
) {
    val appContext = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val countries = remember { WorldFootballRepository.countries() }
    var country by remember { mutableStateOf(countries.firstOrNull { c -> WorldFootballRepository.divisions(c).any { it.name == initialDivision } } ?: "Brasil") }
    val divisions = WorldFootballRepository.divisions(country)
    var division by remember { mutableStateOf(divisions.firstOrNull { it.name == initialDivision } ?: divisions.first()) }
    var clubs by remember { mutableStateOf(ClubCatalog.clubsFor(division.name)) }
    var chosenClub by remember { mutableStateOf<Club?>(clubs.firstOrNull { it.name == initialClub } ?: clubs.firstOrNull()) }
    var loading by remember { mutableStateOf(false) }
    var dataMessage by remember { mutableStateOf("Catálogo local de segurança; buscando escudos e dados remotos...") }
    LaunchedEffect(country) { if (division !in divisions) division = divisions.first() }
    LaunchedEffect(division) {
        chosenClub = null
        loading = true
        dataMessage = "Consultando clubes e escudos..."
        val remote = runCatching { withContext(Dispatchers.IO) { WorldFootballRepository.fetchClubs(appContext, division) } }.getOrNull().orEmpty()
        if (remote.isNotEmpty()) {
            clubs = remote
            chosenClub = remote.firstOrNull { it.name == initialClub } ?: remote.firstOrNull()
            dataMessage = "${remote.size} clubes recebidos do catálogo mundial. Confira dados e direitos dos escudos antes da publicação."
        } else {
            clubs = ClubCatalog.clubsFor(division.name)
            chosenClub = clubs.firstOrNull()
            dataMessage = "Fonte remota indisponível para esta liga. Exibindo dados demonstrativos locais."
        }
        loading = false
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Text("FM27", color = Lime, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        Text("ESCOLHA SEU\\nCLUBE", color = Color.White, fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Black)
        Text("PAÍS  →  DIVISÃO  →  CLUBE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                CardBlock {
                    Text("1. PAÍS", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    countries.forEach { item ->
                        SelectableSetupRow(item, country == item) { country = item }
                    }
                }
            }
            item {
                CardBlock {
                    Text("2. DIVISÃO", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    divisions.forEach { item -> SelectableSetupRow(item.name, division == item) { division = item } }
                }
            }
            item {
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("3. ESCOLHA SEU CLUBE", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.weight(1f)); Text(if (loading) "Carregando..." else "${clubs.size} clubes", color = Muted, fontSize = 10.sp)
                    }
                    clubs.forEach { club ->
                        Row(Modifier.fillMaxWidth().background(if (chosenClub?.id == club.id) Color(0xFF26331B) else Panel2, RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = chosenClub?.id == club.id, onClick = { chosenClub = club }, colors = RadioButtonDefaults.colors(selectedColor = Lime, unselectedColor = Muted))
                            if (club.logoUrl.isNotBlank()) AsyncImage(model = club.logoUrl, contentDescription = "Escudo ${club.name}", modifier = Modifier.size(38.dp))
                            Column(Modifier.weight(1f)) {
                                Text(club.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("${club.stadium} • ${"%,d".format(club.capacity)} lugares", color = Muted, fontSize = 10.sp)
                            }
                            Text("${club.strength}", color = Lime, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(dataMessage, color = Muted, fontSize = 10.sp)
                    Text("Escudos e metadados dependem da cobertura da fonte. O catálogo TheSportsDB é colaborativo; não garante licenciamento comercial nem dados oficiais de todos os países.", color = Muted, fontSize = 9.sp)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { chosenClub?.let { onStart(division.name, it.copy(league = division.name, country = country)) } }, enabled = chosenClub != null && !loading,
            modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg, disabledContainerColor = Panel2), shape = RoundedCornerShape(12.dp)) {
            Text("COMEÇAR COM ${chosenClub?.shortName ?: "CLUBE"}", fontWeight = FontWeight.Black, fontSize = 14.sp)
            Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, contentDescription = null)
        }
    }
}

@Composable
private fun SelectableSetupRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(if (selected) Color(0xFF26331B) else Panel2, RoundedCornerShape(10.dp)), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick, colors = RadioButtonDefaults.colors(selectedColor = Lime, unselectedColor = Muted))
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun Dashboard(round: Int, season: Int, points: Int, played: Int, lastSeasonSummary: String, result: FixtureResult?, managerClub: Club, division: String, onPlay: () -> Unit, onSquad: () -> Unit, onCompetitions: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        if (lastSeasonSummary.isNotBlank()) item {
            CardBlock {
                Text("ÚLTIMA TEMPORADA", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(lastSeasonSummary, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        item {
            CardBlock {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("CARREIRA DO TREINADOR", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(managerClub.name, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                        Text("${managerClub.stadium} • Capacidade ${"%,d".format(managerClub.capacity)}", color = Muted, fontSize = 11.sp)
                    }
                    Box(Modifier.size(54.dp).background(Lime, RoundedCornerShape(13.dp)), Alignment.Center) {
                        Text("78", color = Bg, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip("OVR", "78"); StatChip("PONTOS", "$points"); StatChip("JOGOS", "$played")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Red), shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(division.uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        Spacer(Modifier.weight(1f)); Text("TEMP. $season • $roundª RODADA", color = Color.White, fontSize = 10.sp)
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        ClubBadge(managerClub.shortName)
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(managerClub.shortName, color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text("VS", color = Color(0xFFFFB9BD), fontWeight = FontWeight.Black, fontSize = 25.sp)
                        }
                        ClubBadge("ADV")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(managerClub.name.uppercase(), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("ADVERSÁRIO", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg),
                        shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("SIMULAR PARTIDA", fontWeight = FontWeight.Black)
                    }
                    Text("Simulação rápida • placar e estatísticas ao final", color = Color(0xFFFFDADD), fontSize = 10.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                CardBlock(Modifier.weight(1f)) {
                    Text("CONDIÇÃO", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    ProgressMetric("Energia", .95f, "95"); ProgressMetric("Moral", .88f, "88"); ProgressMetric("Confiança", 1f, "100")
                }
                CardBlock(Modifier.weight(1f)) {
                    Text("COMPETIÇÃO", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("$division • temporada $season", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("$points pontos em $played jogos", color = Muted, fontSize = 10.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("PRÓXIMO OBJETIVO", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Alcançar a zona europeia", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            CardBlock {
                Text("PAINEL DO TREINADOR", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onSquad, modifier = Modifier.weight(1f)) { Text("VER ELENCO", fontSize = 10.sp) }
                    OutlinedButton(onClick = onCompetitions, modifier = Modifier.weight(1f)) { Text("COMPETIÇÕES", fontSize = 10.sp) }
                }
                if (result != null) Text("Último resultado: ${result.homeGoals} x ${result.awayGoals}", color = Lime, fontWeight = FontWeight.Bold)
            }
        }
        item { Text("FUTEBOL27 • CARREIRA EM DESENVOLVIMENTO", color = Muted, fontSize = 9.sp) }
    }
}

@Composable
private fun TacticsScreen(
    club: Club, signedIds: Set<String>, formation: String, startingIds: Set<String>,
    onFormation: (String) -> Unit, onStarting: (Set<String>) -> Unit
) {
    val pool = remember(club.id) { ProceduralGenerator.generatePlayers(count = 5000, seed = 20261028 + club.id) }
    val roster = remember(pool, signedIds) { (pool.take(25) + pool.drop(25).filter { it.id.toString() in signedIds }).distinctBy { it.id } }
    val chosen = roster.filter { it.id.toString() in startingIds }.take(11)
    val starters = if (startingIds.isNotEmpty()) chosen else roster.sortedByDescending { it.overall }.take(11)
    val ids = starters.map { it.id.toString() }.toSet()
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("ESQUEMA TÁTICO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("${club.name} • escalação salva nesta carreira", color = Muted, fontSize = 11.sp)
        }
        item {
            Text("FORMAÇÃO", color = Lime, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("4-3-3", "4-4-2", "3-5-2", "4-2-3-1").forEach { f ->
                    FilterChip(selected = formation == f, onClick = { onFormation(f) }, label = { Text(f) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Lime, selectedLabelColor = Bg, labelColor = Color.White))
                }
            }
        }
        item {
            CardBlock {
                Text("TITULARES • ${starters.size}/11", color = Lime, fontWeight = FontWeight.Bold)
                Text("Selecione até 11 atletas abaixo. Se não houver uma escalação salva, os 11 melhores OVR são sugeridos.", color = Muted, fontSize = 10.sp)
                starters.forEachIndexed { index, player ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}.", color = Lime, modifier = Modifier.width(24.dp))
                        Text(player.position, color = Muted, modifier = Modifier.width(42.dp), fontSize = 10.sp)
                        Text(player.name, color = Color.White, modifier = Modifier.weight(1f), fontSize = 12.sp)
                        Text("${player.overall}", color = Lime, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Text("ELENCO DISPONÍVEL", color = Lime, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
        items(roster, key = { it.id }) { player ->
            val selected = player.id.toString() in ids
            CardBlock {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(player.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("${player.position} • ${player.age} anos • OVR ${player.overall}", color = Muted, fontSize = 10.sp)
                    }
                    Checkbox(checked = selected, onCheckedChange = { checked ->
                        val next = if (checked) (ids + player.id.toString()).take(11).toSet() else ids - player.id.toString()
                        onStarting(next)
                    }, enabled = selected || ids.size < 11, colors = CheckboxDefaults.colors(checkedColor = Lime, checkmarkColor = Bg))
                }
            }
        }
    }
}

@Composable
private fun SquadScreen(club: Club, signedIds: Set<String>, availability: Map<String, PlayerAvailability>) {
    // O mesmo universo determinístico alimenta o elenco e o mercado; atletas contratados
    // passam a aparecer aqui sem fotos ou retratos.
    val playerPool = remember(club.id) { ProceduralGenerator.generatePlayers(count = 5000, seed = 20261028 + club.id) }
    val generatedPlayers = remember(playerPool, signedIds) {
        (playerPool.take(25) + playerPool.drop(25).filter { it.id.toString() in signedIds }).distinctBy { it.id }
    }
    var search by remember { mutableStateOf("") }
    var selectedPosition by remember { mutableStateOf("TODAS") }
    val filtered = remember(search, selectedPosition, generatedPlayers) {
        generatedPlayers.filter {
            (search.isBlank() || it.name.contains(search, ignoreCase = true) || it.nationality.contains(search, ignoreCase = true)) &&
                (selectedPosition == "TODAS" || it.position == selectedPosition)
        }
    }
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("ELENCO • ${club.name.uppercase()}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("${generatedPlayers.size} atletas • jogadores fictícios • sem fotos • lesões e suspensões", color = Muted, fontSize = 11.sp)
        }
        item {
            OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar nome ou nacionalidade") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }, singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Lime, unfocusedBorderColor = Color(0xFF30394A), focusedTextColor = Color.White, unfocusedTextColor = Color.White))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("TODAS", "GOL", "ZAG", "LAT", "VOL", "MEI", "PON", "ATA").forEach { pos ->
                    FilterChip(selected = selectedPosition == pos, onClick = { selectedPosition = pos }, label = { Text(pos, fontSize = 9.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Lime, selectedLabelColor = Bg, labelColor = Muted))
                }
            }
            Text("${filtered.size} jogadores encontrados", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        items(filtered, key = { it.id }) { p ->
            CardBlock {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(39.dp).background(Color(0xFF26331B), CircleShape), Alignment.Center) {
                        Text(p.position, color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("${p.nationality} • ${p.age} anos • Nasc. ${p.birthDate}", color = Muted, fontSize = 9.sp)
                        Text("Pot. ${p.potential} • Valor €${String.format("%,d", p.marketValue)} • €${p.weeklySalary}/sem.", color = Muted, fontSize = 9.sp)
                        Text("Contrato até ${p.contractEnd}", color = Muted, fontSize = 9.sp)
                        availability[p.id.toString()]?.let { status ->
                            val label = when { status.matchesOut > 0 -> "INDISPONÍVEL • ${status.matchesOut} rodada(s)"; status.suspended -> "SUSPENSO"; status.yellowAccumulation > 0 -> "${status.yellowAccumulation}/5 amarelos"; else -> "DISPONÍVEL" }
                            Text(label, color = if (status.matchesOut > 0 || status.suspended) Color(0xFFFF7777) else Color(0xFFFFC15A), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.background(Lime, RoundedCornerShape(7.dp)).padding(horizontal = 8.dp, vertical = 5.dp)) {
                            Text("${p.overall}", color = Bg, fontWeight = FontWeight.Black, fontSize = 13.sp)
                        }
                        Text("OVR", color = Muted, fontSize = 8.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrainingScreen(club: Club, signedIds: Set<String>, xp: Map<String, Int>, balance: Long, onTrain: (Player) -> Boolean) {
    val pool = remember(club.id) { ProceduralGenerator.generatePlayers(count = 5000, seed = 20261028 + club.id) }
    val players = remember(pool, signedIds, xp) {
        (pool.take(25) + pool.drop(25).filter { it.id.toString() in signedIds }).distinctBy { it.id }
            .map { p -> p.copy(overall = (p.overall + (xp["grown_${p.id}"] ?: 0)).coerceAtMost(p.potential)) }
            .sortedByDescending { it.overall }
    }
    var position by remember { mutableStateOf("TODAS") }
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            Text("CENTRO DE TREINAMENTO", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
            Text("Treinos individuais • sem retratos de atletas", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(5.dp))
            CardBlock {
                Text("CAIXA DISPONÍVEL", color = Muted, fontSize = 10.sp)
                Text("€ ${String.format("%,d", balance)}", color = Lime, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Custo por sessão: € ${String.format("%,d", TrainingEngine.SESSION_COST)}", color = Muted, fontSize = 10.sp)
                Text("A cada 3 sessões, o jogador pode ganhar +1 OVR, até o potencial.", color = Color.White, fontSize = 11.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("TODAS", "GOL", "ZAG", "LAT", "VOL", "MEI", "PON", "ATA").forEach { pos ->
                    FilterChip(selected = position == pos, onClick = { position = pos }, label = { Text(pos, fontSize = 9.sp) })
                }
            }
        }
        items(players.filter { position == "TODAS" || it.position == position }, key = { it.id }) { player ->
            CardBlock {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(player.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("${player.position} • ${player.age} anos • ${player.nationality}", color = Muted, fontSize = 10.sp)
                        Text("OVR ${player.overall}  |  Potencial ${player.potential}  |  Sessões ${xp[player.id.toString()] ?: 0}/3", color = Lime, fontSize = 10.sp)
                    }
                    Button(onClick = { onTrain(player) }, enabled = player.overall < player.potential && balance >= TrainingEngine.SESSION_COST,
                        colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)) {
                        Text("TREINAR", fontSize = 9.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun CompetitionsScreen(round: Int, points: Int, played: Int, country: String, clubs: List<Club>, fixtures: List<LeagueFixture>, results: List<RecordedFixtureResult>) {
    val rows = LeagueEngine.standings(clubs, fixtures, results)
    val identities = CompetitionCatalog.forCountry(country)
    val completedFixtures = results.mapNotNull { result ->
        val fixture = fixtures.firstOrNull { it.id == result.fixtureId } ?: return@mapNotNull null
        val home = clubs.firstOrNull { it.id == fixture.homeClubId } ?: return@mapNotNull null
        val away = clubs.firstOrNull { it.id == fixture.awayClubId } ?: return@mapNotNull null
        Triple(home.name, result, away.name)
    }
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("COMPETIÇÕES", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("Universo mundial • $country", color = Muted, fontSize = 11.sp)
        }
        item {
            CardBlock {
                Text("CATÁLOGO DE COMPETIÇÕES", color = Lime, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text("Identidades locais padronizadas; não dependem de imagens externas.", color = Muted, fontSize = 10.sp)
                identities.forEach { competition ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Color(competition.colorHex), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            Text(competition.mark, color = Color.White, fontWeight = FontWeight.Black, fontSize = if (competition.mark.length > 2) 9.sp else 13.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(competition.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("${competition.country} • ${competition.region}", color = Muted, fontSize = 10.sp)
                            Text(competition.format, color = Lime, fontSize = 9.sp)
                        }
                    }
                    HorizontalDivider(color = Color(0xFF252D3B))
                }
            }
        }
        item {
            CardBlock {
                Text("CLASSIFICAÇÃO DA CARREIRA", color = Lime, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text("${results.size} partidas concluídas • ${fixtures.size} jogos no calendário", color = Muted, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
                    Text("CLUBE", Modifier.weight(1f), color = Muted, fontSize = 9.sp)
                    Text("J", Modifier.width(22.dp), color = Muted, fontSize = 9.sp)
                    Text("V", Modifier.width(22.dp), color = Muted, fontSize = 9.sp)
                    Text("E", Modifier.width(22.dp), color = Muted, fontSize = 9.sp)
                    Text("D", Modifier.width(22.dp), color = Muted, fontSize = 9.sp)
                    Text("SG", Modifier.width(30.dp), color = Muted, fontSize = 9.sp)
                    Text("PTS", Modifier.width(32.dp), color = Lime, fontSize = 9.sp)
                }
                rows.forEachIndexed { i, row ->
                    HorizontalDivider(color = Color(0xFF252D3B))
                    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}. ${row.clubName}", Modifier.weight(1f), color = if (i == 0) Lime else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("${row.played}", Modifier.width(22.dp), color = Muted, fontSize = 10.sp)
                        Text("${row.wins}", Modifier.width(22.dp), color = Muted, fontSize = 10.sp)
                        Text("${row.draws}", Modifier.width(22.dp), color = Muted, fontSize = 10.sp)
                        Text("${row.losses}", Modifier.width(22.dp), color = Muted, fontSize = 10.sp)
                        Text("${row.goalDifference}", Modifier.width(30.dp), color = Muted, fontSize = 10.sp)
                        Text("${row.points}", Modifier.width(32.dp), color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                }
            }
        }
        if (completedFixtures.isNotEmpty()) item {
            CardBlock {
                Text("RESULTADOS REGISTRADOS", color = Lime, fontWeight = FontWeight.Black, fontSize = 14.sp)
                completedFixtures.asReversed().forEach { (home, result, away) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(home, Modifier.weight(1f), color = Color.White, fontSize = 10.sp)
                        Text("${result.homeGoals} × ${result.awayGoals}", color = Lime, fontWeight = FontWeight.Black, fontSize = 13.sp)
                        Text(away, Modifier.weight(1f), color = Color.White, fontSize = 10.sp, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarScreen(round: Int, result: FixtureResult?, home: Club, away: Club, onSimulate: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(13.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CALENDÁRIO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("Próxima partida • ${home.league.ifBlank { "Liga nacional" }} • Rodada $round", color = Muted, fontSize = 12.sp)
        CardBlock {
            Text("${home.name.uppercase()}  x  ${away.name.uppercase()}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text("${home.stadium} • mando de ${home.name}", color = Muted, fontSize = 11.sp)
            Button(onClick = onSimulate, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.PlayArrow, null); Text("SIMULAR E AVANÇAR RODADA", fontWeight = FontWeight.Black)
            }
        }
        if (result != null) CardBlock {
            Text("ÚLTIMO RESULTADO", color = Lime, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Text("${result.home} ${result.homeGoals} x ${result.awayGoals} ${result.away}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
            Text("Posse: ${result.possessionHome}% • Finalizações: ${result.shotsHome} x ${result.shotsAway}", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun FinanceScreen(balance: Long, transferBudget: Long, seasonRevenue: Long, onBudgetChange: (Long) -> Unit) {
    var showBudget by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(13.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("FINANÇAS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("Gestão financeira da carreira", color = Muted, fontSize = 11.sp)
        }
        item { CardBlock {
            Text("SALDO DO CLUBE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("€ ${String.format("%,d", balance)}", color = Lime, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("Saldo atualizado após cada partida simulada", color = Muted, fontSize = 10.sp)
        } }
        item { CardBlock {
            FinanceLine("Receitas acumuladas", "€ ${String.format("%,d", seasonRevenue)}")
            FinanceLine("Orçamento de transferências", "€ ${String.format("%,d", transferBudget)}")
            FinanceLine("Folha salarial estimada / semana", "€ 166.000")
            FinanceLine("Receita comercial por rodada", "€ 85.000")
            OutlinedButton(onClick = { showBudget = true }, modifier = Modifier.fillMaxWidth()) { Text("GERENCIAR ORÇAMENTO") }
        } }
        item { CardBlock {
            Text("MOVIMENTAÇÃO POR PARTIDA", color = Lime, fontWeight = FontWeight.Bold)
            Text("Bilheteria estimada conforme capacidade do estádio e força do clube. A receita comercial e a folha salarial são valores de simulação.", color = Muted, fontSize = 11.sp)
        } }
    }
    if (showBudget) AlertDialog(onDismissRequest = { showBudget = false }, containerColor = Panel,
        title = { Text("ORÇAMENTO DE TRANSFERÊNCIAS", color = Lime, fontWeight = FontWeight.Black) },
        text = { Text("Defina o orçamento disponível. O valor é limitado ao saldo atual do clube.", color = Color.White) },
        confirmButton = { TextButton(onClick = { onBudgetChange(minOf(balance, transferBudget + 250_000L)); showBudget = false }) { Text("AUMENTAR €250 MIL") } },
        dismissButton = { TextButton(onClick = { onBudgetChange((transferBudget - 250_000L).coerceAtLeast(0L)); showBudget = false }) { Text("REDUZIR €250 MIL") } })
}

@Composable
private fun MatchResultDialog(result: FixtureResult, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel,
        title = { Text("APITO FINAL", color = Lime, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("${result.home} ${result.homeGoals} x ${result.awayGoals} ${result.away}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                HorizontalDivider(color = Color(0xFF30394A))
                ProgressMetric("Posse de ${result.home}", result.possessionHome / 100f, "${result.possessionHome}%")
                ProgressMetric("Finalizações ${result.home}", (result.shotsHome / 25f).coerceIn(0f, 1f), "${result.shotsHome}")
                ProgressMetric("Finalizações ${result.away}", (result.shotsAway / 25f).coerceIn(0f, 1f), "${result.shotsAway}")
                Text("Cartões amarelos: ${result.yellowCards}", color = Muted, fontSize = 12.sp)
                Text("Cartões vermelhos: ${result.redCards}", color = if (result.redCards > 0) Color(0xFFFF6262) else Muted, fontSize = 12.sp)
                Text("Lesões registradas: ${result.injuries}", color = if (result.injuries > 0) Color(0xFFFFB454) else Muted, fontSize = 12.sp)
                Text(result.summary, color = Color.White, fontSize = 12.sp)
                Text("Eventos disciplinares e físicos são simulados junto com o resultado.", color = Muted, fontSize = 10.sp)
            }
        },
        confirmButton = { Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)) { Text("CONTINUAR", fontWeight = FontWeight.Black) } }
    )
}

@Composable
private fun CardBlock(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Color(0xFF252D3A))) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp), content = content)
    }
}
@Composable
private fun StatChip(label: String, value: String) {
    Column(Modifier.background(Panel2, RoundedCornerShape(9.dp)).padding(horizontal = 10.dp, vertical = 8.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}
@Composable
private fun ClubBadge(text: String) {
    Box(Modifier.size(56.dp).background(Color(0xFFF1F2F4), RoundedCornerShape(10.dp)), Alignment.Center) {
        Text(text, color = Red, fontSize = 14.sp, fontWeight = FontWeight.Black)
    }
}
@Composable
private fun ProgressMetric(label: String, value: Float, trailing: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), color = Muted, fontSize = 10.sp)
            Text(trailing, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = { value.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(5.dp), color = Green, trackColor = Color(0xFF273140))
    }
}
@Composable
private fun FinanceLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
