package com.futebol27.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 10, 16)
        window.navigationBarColor = android.graphics.Color.rgb(7, 10, 16)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFC5FF36), secondary = Color(0xFF37D995),
                background = Color(0xFF070A10), surface = Color(0xFF121824),
                onPrimary = Color(0xFF10150A), onBackground = Color(0xFFF4F6FA),
                onSurface = Color(0xFFF4F6FA)
            )) { Futebol27App() }
        }
    }
}
