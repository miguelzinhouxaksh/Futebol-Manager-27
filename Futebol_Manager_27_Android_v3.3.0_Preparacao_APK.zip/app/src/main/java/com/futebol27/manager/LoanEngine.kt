package com.futebol27.manager

/** Regras de empréstimo em rodadas, com custo salarial dividido entre os clubes. */
object LoanEngine {
    const val DEFAULT_DURATION_ROUNDS = 12
    const val DEFAULT_WAGE_SHARE_PERCENT = 50

    fun weeklyCost(player: Player, wageSharePercent: Int = DEFAULT_WAGE_SHARE_PERCENT): Long {
        require(wageSharePercent in 0..100)
        return (player.weeklySalary * wageSharePercent / 100L).coerceAtLeast(0L)
    }

    fun createContract(player: Player, rounds: Int, parentClub: String): LoanContract {
        require(rounds in 1..38)
        require(parentClub.isNotBlank())
        return LoanContract(
            playerId = player.id,
            roundsRemaining = rounds,
            weeklyWageShare = weeklyCost(player),
            parentClub = parentClub
        )
    }

    /** Decrementa o prazo; contratos encerrados são devolvidos e removidos do mapa. */
    fun advanceRound(contracts: Map<String, LoanContract>): Map<String, LoanContract> =
        contracts.mapNotNull { (id, contract) ->
            val remaining = contract.roundsRemaining - 1
            if (remaining <= 0) null else id to contract.copy(roundsRemaining = remaining)
        }.toMap()

    fun returnedPlayerIds(before: Map<String, LoanContract>, after: Map<String, LoanContract>): Set<String> =
        before.keys - after.keys
}

/** Empréstimos de atletas próprios: o clube cedente recebe contribuição salarial. */
object OutgoingLoanEngine {
    const val DEFAULT_WAGE_CONTRIBUTION_PERCENT = 50

    fun createContract(
        player: Player,
        borrowerClub: String,
        rounds: Int,
        contributionPercent: Int = DEFAULT_WAGE_CONTRIBUTION_PERCENT
    ): OutgoingLoanContract {
        require(borrowerClub.isNotBlank())
        require(rounds in 1..38)
        require(contributionPercent in 0..100)
        return OutgoingLoanContract(
            playerId = player.id,
            borrowerClub = borrowerClub,
            roundsRemaining = rounds,
            weeklyWageContribution = (player.weeklySalary * contributionPercent / 100L).coerceAtLeast(0L)
        )
    }

    fun advanceRound(contracts: Map<String, OutgoingLoanContract>): Map<String, OutgoingLoanContract> =
        contracts.mapNotNull { (id, contract) ->
            val remaining = contract.roundsRemaining - 1
            if (remaining <= 0) null else id to contract.copy(roundsRemaining = remaining)
        }.toMap()

    fun returnedPlayerIds(
        before: Map<String, OutgoingLoanContract>,
        after: Map<String, OutgoingLoanContract>
    ): Set<String> = before.keys - after.keys

    fun netWeeklyWage(player: Player, contract: OutgoingLoanContract?): Long =
        (player.weeklySalary - (contract?.weeklyWageContribution ?: 0L)).coerceAtLeast(0L)
}
