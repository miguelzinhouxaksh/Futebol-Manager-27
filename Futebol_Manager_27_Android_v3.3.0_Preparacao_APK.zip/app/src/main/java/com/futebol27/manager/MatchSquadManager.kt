package com.futebol27.manager

/** Gestão simplificada de energia e substituições automáticas durante a partida. */
data class MatchSquadPlan(
    val starters: List<Player>,
    val bench: List<Player>,
    val finalLineup: List<Player>,
    val substitutions: List<Pair<Player, Player>>,
    val fatigueAfterMatch: Map<String, Int>,
    val effectiveOverall: Int
)

object MatchSquadManager {
    const val MAX_SUBSTITUTIONS = 5
    const val BENCH_SIZE = 9

    fun prepare(
        roster: List<Player>,
        requestedStarterIds: Set<String>,
        fatigue: Map<String, Int>,
        randomSeed: Int,
        morale: Map<String, Int> = emptyMap()
    ): MatchSquadPlan {
        val available = roster.distinctBy { it.id }
        val ordered = available.sortedWith(
            compareByDescending<Player> { it.id.toString() in requestedStarterIds }
                .thenByDescending { PlayerCareerEngine.effectiveOverall(it.overall, morale[it.id.toString()] ?: 70) - (fatigue[it.id.toString()] ?: 0) / 12 }
        )
        val starters = ordered.take(11)
        val bench = ordered.drop(11).take(BENCH_SIZE)
        val final = starters.toMutableList()
        val changes = mutableListOf<Pair<Player, Player>>()
        val usedBench = mutableSetOf<Int>()
        // Decisão reproduzível: atletas com energia baixa podem ser substituídos
        // por reservas de mesma faixa de posição, respeitando o limite de cinco.
        starters.forEachIndexed { index, starter ->
            if (changes.size >= MAX_SUBSTITUTIONS) return@forEachIndexed
            val energy = 100 - (fatigue[starter.id.toString()] ?: 0)
            if (energy > 58) return@forEachIndexed
            val reserve = bench.withIndex().firstOrNull { (benchIndex, candidate) ->
                benchIndex !in usedBench && compatible(starter.position, candidate.position) &&
                    candidate.overall - (fatigue[candidate.id.toString()] ?: 0) / 12 >= starter.overall - 2
            } ?: return@forEachIndexed
            usedBench += reserve.index
            final[index] = reserve.value
            changes += starter to reserve.value
        }
        val after = fatigue.toMutableMap()
        starters.forEach { player ->
            val played = changes.none { it.first.id == player.id }
            val current = fatigue[player.id.toString()] ?: 0
            after[player.id.toString()] = (current + if (played) 22 else 8).coerceIn(0, 90)
        }
        bench.forEach { player ->
            val current = fatigue[player.id.toString()] ?: 0
            after[player.id.toString()] = (current + if (changes.any { it.second.id == player.id }) 10 else -18).coerceIn(0, 90)
        }
        val average = final.map { PlayerCareerEngine.effectiveOverall(it.overall, morale[it.id.toString()] ?: 70) - (after[it.id.toString()] ?: 0) / 20 }.average()
            .takeIf { !it.isNaN() }?.toInt() ?: 60
        return MatchSquadPlan(starters, bench, final, changes, after, average)
    }

    fun recoverBetweenRounds(fatigue: Map<String, Int>): Map<String, Int> =
        fatigue.mapValues { (_, value) -> (value - 35).coerceAtLeast(0) }

    private fun compatible(a: String, b: String): Boolean {
        if (a == b) return true
        val defense = setOf("ZAG", "LAT")
        val midfield = setOf("VOL", "MEI", "PON")
        return (a in defense && b in defense) || (a in midfield && b in midfield)
    }
}
