package com.futebol27.manager

import kotlin.random.Random

data class Player(
    val id: Int, val name: String, val position: String, val age: Int,
    val overall: Int, val birthDate: String, val nationality: String,
    val potential: Int = overall,
    val marketValue: Long = 0L,
    val weeklySalary: Long = 0L,
    val contractStart: String = "01/07/2026",
    val contractEnd: String = "30/06/2029",
    val attributes: PlayerAttributes = PlayerAttributes()
)

data class LoanContract(
    val playerId: Int,
    val roundsRemaining: Int,
    val weeklyWageShare: Long,
    val parentClub: String
)

data class PlayerAttributes(
    val pace: Int = 50, val shooting: Int = 50, val passing: Int = 50,
    val dribbling: Int = 50, val defending: Int = 50, val physical: Int = 50,
    val goalkeeping: Int = 10
)
data class Club(
    val id: Int, val name: String, val shortName: String, val strength: Int,
    val stadium: String, val capacity: Int, val logoUrl: String = "", val country: String = "", val league: String = ""
)
data class FixtureResult(
    val home: String, val away: String, val homeGoals: Int, val awayGoals: Int,
    val possessionHome: Int, val shotsHome: Int, val shotsAway: Int,
    val yellowCards: Int, val summary: String,
    val redCards: Int = 0, val injuries: Int = 0
)
data class LeagueRow(val club: String, val points: Int, val played: Int, val gf: Int, val ga: Int) {
    val gd: Int get() = gf - ga
}
object DemoData {
    val clubs = listOf(
        Club(1, "Athletic Club", "ATH", 78, "San Mamés", 53289),
        Club(2, "Sporting Gijón", "GIJ", 71, "El Molinón", 30000),
        Club(3, "Real Sociedad", "RSO", 80, "Reale Arena", 39500),
        Club(4, "Valencia CF", "VAL", 76, "Mestalla", 49430),
        Club(5, "Sevilla FC", "SEV", 79, "Ramón Sánchez-Pizjuán", 43883)
    )
    val players = listOf(
        Player(1, "Iker Navarro", "GOL", 24, 76, "14/02/2002", "Espanha"),
        Player(2, "Álvaro Martín", "ZAG", 27, 78, "03/11/1998", "Espanha"),
        Player(3, "Nico Serrano", "MEI", 22, 80, "05/03/2004", "Espanha"),
        Player(4, "Mateo Ruiz", "ATA", 21, 82, "19/07/2005", "Espanha"),
        Player(5, "Bruno Costa", "VOL", 25, 75, "28/09/2001", "Portugal"),
        Player(6, "Daniel Vega", "LAT", 23, 74, "11/01/2003", "Espanha"),
        Player(7, "Hugo Santos", "ATA", 29, 77, "24/06/1997", "Brasil"),
        Player(8, "Lucas Ferreira", "MEI", 20, 72, "09/12/2005", "Brasil"),
        Player(9, "Gabriel Torres", "ZAG", 26, 73, "16/04/2000", "Uruguai"),
        Player(10, "Samuel Ortiz", "GOL", 19, 68, "30/08/2007", "Espanha")
    )
}
object MatchEngine {
    fun simulate(
        home: Club, away: Club, random: Random = Random.Default,
        homeFormation: String = "4-3-3", homeLineupOverall: Int? = null
    ): FixtureResult {
        // A escalação e a formação escolhidas pelo treinador influenciam o desempenho
        // sem tornar o resultado determinístico ou eliminar a vantagem do adversário.
        val lineupAdjustment = (((homeLineupOverall ?: home.strength) - home.strength) / 12.0).coerceIn(-2.5, 2.5)
        val formationAdjustment = when (homeFormation) {
            "4-3-3" -> 0.18
            "4-4-2" -> 0.10
            "3-5-2" -> 0.05
            "4-2-3-1" -> 0.22
            else -> 0.0
        }
        val tacticalBoost = lineupAdjustment + formationAdjustment
        val homeExpected = ((home.strength + 4 - away.strength) / 18.0 + 1.25 + tacticalBoost * 0.12).coerceIn(0.15, 3.4)
        val awayExpected = ((away.strength - home.strength - 2) / 20.0 + 1.05 - tacticalBoost * 0.06).coerceIn(0.15, 3.1)
        fun goals(expected: Double): Int {
            val r = random.nextDouble()
            return when {
                r < (expected * 0.18).coerceAtMost(0.48) -> 2
                r < (expected * 0.31).coerceAtMost(0.72) -> 1
                r < (expected * 0.36).coerceAtMost(0.88) -> 3
                else -> 0
            }
        }
        val hg = goals(homeExpected)
        val ag = goals(awayExpected)
        val possession = (48 + (home.strength - away.strength) / 2 + tacticalBoost.toInt() + random.nextInt(-8, 9)).coerceIn(30, 70)
        val sh = (7 + home.strength / 9 + tacticalBoost.toInt() + random.nextInt(-3, 5)).coerceAtLeast(1)
        val sa = (7 + away.strength / 9 + random.nextInt(-3, 5)).coerceAtLeast(1)
        val cards = random.nextInt(1, 7)
        val reds = if (random.nextDouble() < 0.13) 1 else 0
        val injuries = when { random.nextDouble() < 0.035 -> 2; random.nextDouble() < 0.18 -> 1; else -> 0 }
        val summary = when {
            hg > ag -> "${home.name} venceu com vantagem no mando de campo."
            hg < ag -> "${away.name} foi eficiente fora de casa."
            else -> "Empate equilibrado; os times dividiram os pontos."
        }
        return FixtureResult(home.name, away.name, hg, ag, possession, sh, sa, cards, summary, reds, injuries)
    }
}

/** Catálogo inicial por divisão. Valores de força/estádio são dados de protótipo, não feed oficial. */
object ClubCatalog {
    private fun club(id: Int, name: String, short: String, strength: Int, stadium: String, capacity: Int) =
        Club(id, name, short, strength, stadium, capacity)

    private val catalog = mapOf(
        "Brasileirão Série A" to listOf(
            club(101,"Flamengo","FLA",84,"Maracanã",78838), club(102,"Palmeiras","PAL",83,"Allianz Parque",43713),
            club(103,"São Paulo","SAO",80,"MorumBIS",66795), club(104,"Corinthians","COR",79,"Neo Química Arena",49205),
            club(105,"Santos","SAN",76,"Vila Belmiro",20000), club(106,"Grêmio","GRE",79,"Arena do Grêmio",55662)
        ),
        "Brasileirão Série B" to listOf(
            club(201,"Athletico Paranaense","CAP",76,"Ligga Arena",42372), club(202,"Coritiba","CFC",73,"Couto Pereira",40502),
            club(203,"Goiás","GOI",72,"Hailé Pinheiro",14525), club(204,"Cuiabá","CUI",72,"Arena Pantanal",44200),
            club(205,"América Mineiro","AME",71,"Independência",23018), club(206,"CRB","CRB",69,"Rei Pelé",17000)
        ),
        "Brasileirão Série C" to listOf(
            club(301,"Náutico","NAU",68,"Aflitos",22000), club(302,"Ponte Preta","PON",68,"Moisés Lucarelli",17728),
            club(303,"Figueirense","FIG",67,"Orlando Scarpelli",19908), club(304,"Botafogo-PB","BOT",67,"Almeidão",25000)
        ),
        "Brasileirão Série D" to listOf(
            club(401,"ABC","ABC",64,"Frasqueirão",18000), club(402,"ASA","ASA",63,"Fumeirão",12000),
            club(403,"Portuguesa-RJ","POR",62,"Luso-Brasileiro",5000), club(404,"Anápolis","ANA",63,"Jonas Duarte",20000)
        ),
        "Premier League" to listOf(
            club(501,"Manchester City","MCI",88,"Etihad Stadium",53400), club(502,"Arsenal","ARS",86,"Emirates Stadium",60704),
            club(503,"Liverpool","LIV",87,"Anfield",61276), club(504,"Manchester United","MUN",83,"Old Trafford",74879)
        ),
        "LaLiga" to listOf(
            club(601,"Real Madrid","RMA",90,"Santiago Bernabéu",83186), club(602,"Barcelona","BAR",88,"Estadi Olímpic Lluís Companys",55000),
            club(603,"Atlético de Madrid","ATM",85,"Riyadh Air Metropolitano",70460), club(604,"Athletic Club","ATH",78,"San Mamés",53289)
        ),
        "Serie A Italiana" to listOf(
            club(701,"Inter","INT",87,"San Siro",75817), club(702,"Juventus","JUV",84,"Allianz Stadium",41507),
            club(703,"Milan","MIL",85,"San Siro",75817), club(704,"Napoli","NAP",84,"Stadio Diego Armando Maradona",54726)
        ),
        "Bundesliga" to listOf(
            club(801,"Bayern München","BAY",89,"Allianz Arena",75024), club(802,"Borussia Dortmund","BVB",85,"Signal Iduna Park",81365),
            club(803,"Bayer Leverkusen","B04",85,"BayArena",30210), club(804,"RB Leipzig","RBL",82,"Red Bull Arena",47069)
        ),
        "Ligue 1" to listOf(
            club(901,"Paris Saint-Germain","PSG",89,"Parc des Princes",47929), club(902,"Marseille","OM",81,"Orange Vélodrome",67394),
            club(903,"Monaco","ASM",82,"Stade Louis II",16500), club(904,"Lyon","OL",80,"Groupama Stadium",59186)
        ),
        "Liga Portugal" to listOf(
            club(1001,"Benfica","BEN",85,"Estádio da Luz",65647), club(1002,"Porto","FCP",84,"Estádio do Dragão",50033),
            club(1003,"Sporting CP","SCP",84,"Estádio José Alvalade",52095), club(1004,"Braga","BRA",78,"Estádio Municipal de Braga",30286)
        )
    )
    fun clubsFor(division: String): List<Club> = catalog[division] ?: catalog.values.first()
}

data class OutgoingLoanContract(
    val playerId: Int,
    val borrowerClub: String,
    val roundsRemaining: Int,
    val weeklyWageContribution: Long
)
