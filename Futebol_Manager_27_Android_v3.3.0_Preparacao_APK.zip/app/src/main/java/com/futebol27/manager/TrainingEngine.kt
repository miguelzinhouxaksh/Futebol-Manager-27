package com.futebol27.manager

/** Progressão simples de treino: três sessões concedem +1 OVR, sem ultrapassar o potencial. */
object TrainingEngine {
    const val SESSION_COST = 20_000L
    fun train(player: Player, currentXp: Int): Pair<Int, Int> {
        if (player.overall >= player.potential) return currentXp.coerceAtMost(2) to 0
        val nextXp = currentXp + 1
        return if (nextXp >= 3) 0 to 1 else nextXp to 0
    }
}
