package com.futebol27.manager

import org.junit.Assert.*
import org.junit.Test

class LoanEngineTest {
    private val player = DemoData.players.first().copy(weeklySalary = 20_000L)

    @Test fun weeklyWageShareDefaultsToHalf() {
        assertEquals(10_000L, LoanEngine.weeklyCost(player))
    }

    @Test fun contractStoresDurationAndParentClub() {
        val contract = LoanEngine.createContract(player, 12, "Clube parceiro")
        assertEquals(12, contract.roundsRemaining)
        assertEquals("Clube parceiro", contract.parentClub)
        assertEquals(10_000L, contract.weeklyWageShare)
    }

    @Test fun loanReturnsAfterLastRound() {
        val contracts = mapOf(player.id.toString() to LoanEngine.createContract(player, 1, "Clube parceiro"))
        val advanced = LoanEngine.advanceRound(contracts)
        assertTrue(advanced.isEmpty())
        assertEquals(setOf(player.id.toString()), LoanEngine.returnedPlayerIds(contracts, advanced))
    }

    @Test fun longerLoanKeepsContractUntilExpiry() {
        val id = player.id.toString()
        val first = mapOf(id to LoanEngine.createContract(player, 3, "Clube parceiro"))
        val second = LoanEngine.advanceRound(first)
        assertEquals(2, second[id]?.roundsRemaining)
        val third = LoanEngine.advanceRound(second)
        assertEquals(1, third[id]?.roundsRemaining)
        assertTrue(LoanEngine.advanceRound(third).isEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun invalidLoanDurationIsRejected() {
        LoanEngine.createContract(player, 0, "Clube parceiro")
    }
}

class OutgoingLoanEngineTest {
    private val player = DemoData.players.first().copy(weeklySalary = 20_000L)

    @Test fun createsOutgoingLoanAndSalaryContribution() {
        val contract = OutgoingLoanEngine.createContract(player, "Clube parceiro", 12, 50)
        assertEquals("Clube parceiro", contract.borrowerClub)
        assertEquals(12, contract.roundsRemaining)
        assertEquals(10_000L, contract.weeklyWageContribution)
        assertEquals(10_000L, OutgoingLoanEngine.netWeeklyWage(player, contract))
    }

    @Test fun outgoingPlayerReturnsWithoutLosingOwnership() {
        val id = player.id.toString()
        val active = mapOf(id to OutgoingLoanEngine.createContract(player, "Clube parceiro", 1))
        val after = OutgoingLoanEngine.advanceRound(active)
        assertTrue(after.isEmpty())
        assertEquals(setOf(id), OutgoingLoanEngine.returnedPlayerIds(active, after))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsInvalidContributionPercent() {
        OutgoingLoanEngine.createContract(player, "Clube parceiro", 10, 120)
    }
}
