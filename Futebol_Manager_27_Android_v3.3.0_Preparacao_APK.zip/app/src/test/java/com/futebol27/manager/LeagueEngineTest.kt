package com.futebol27.manager
import org.junit.Assert.*
import org.junit.Test

class LeagueEngineTest {
    private fun teams(n:Int)=(1..n).map { Club(it,"Clube $it","C$it",65,"Estádio",10000) }
    @Test fun sixClubsHaveThirtyFixturesAndTenRounds() {
        val f=LeagueEngine.createDoubleRoundRobin(teams(6))
        assertEquals(30,f.size); assertEquals(10,f.map{it.round}.distinct().size)
    }
    @Test fun oddClubsHaveCompleteSchedule() {
        val f=LeagueEngine.createDoubleRoundRobin(teams(5))
        assertEquals(20,f.size); assertEquals(8,f.map{it.round}.distinct().size)
    }
    @Test fun winAwardsThreePoints() {
        val c=teams(3); val f=LeagueEngine.createDoubleRoundRobin(c); val match=f.first()
        val t=LeagueEngine.standings(c,f,listOf(RecordedFixtureResult(match.id,2,0)))
        assertEquals(3,t.first{it.clubId==match.homeClubId}.points)
        assertEquals(0,t.first{it.clubId==match.awayClubId}.points)
    }
    @Test fun completingRoundSimulatesEveryOtherFixtureAndKeepsUserScore() {
        val c = teams(6)
        val fixtures = LeagueEngine.createDoubleRoundRobin(c)
        val roundFixtures = fixtures.filter { it.round == 1 }
        val user = roundFixtures.first()
        val completed = LeagueEngine.completeRound(
            fixtures, emptyList(), 1, user.id, 3, 1
        ) { fixture -> RecordedFixtureResult(fixture.id, 0, 0) }
        assertEquals(roundFixtures.size, completed.size)
        assertEquals(3, completed.first { it.fixtureId == user.id }.homeGoals)
        assertEquals(1, completed.first { it.fixtureId == user.id }.awayGoals)
        assertEquals(roundFixtures.size * 2, LeagueEngine.standings(c, fixtures, completed).sumOf { it.played })
    }

    @Test(expected=IllegalArgumentException::class) fun rejectsDuplicateIds() {
        val c=teams(2); LeagueEngine.createDoubleRoundRobin(listOf(c[0],c[0]))
    }
}

class PlayerCareerEngineTest {
    @org.junit.Test fun renewalAcceptsFairOfferAndRaisesMorale() {
        val player = DemoData.players.first()
        val state = PlayerCareerState(morale = 70)
        val offer = PlayerCareerEngine.suggestedOffer(player, state)
        val decision = PlayerCareerEngine.decideRenewal(player, state, offer)
        org.junit.Assert.assertTrue(decision.accepted)
        org.junit.Assert.assertEquals(80, decision.state.morale)
    }

    @org.junit.Test fun lowMoraleReducesEffectiveOverall() {
        org.junit.Assert.assertTrue(PlayerCareerEngine.effectiveOverall(75, 20) < 75)
        org.junit.Assert.assertTrue(PlayerCareerEngine.effectiveOverall(75, 90) > 75)
    }
}
