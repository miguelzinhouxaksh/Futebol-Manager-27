package com.futebol27.manager

import org.junit.Assert.*
import org.junit.Test

class TransferNegotiationEngineTest {
    private val player = DemoData.players.first().copy(marketValue = 1_000_000L)

    @Test fun openingOfferIsEightyPercentOfMarketValue() {
        assertEquals(800_000L, TransferNegotiationEngine.openingOffer(player))
    }

    @Test fun counterOfferIsTenPercentAboveMarketValue() {
        assertEquals(1_100_000L, TransferNegotiationEngine.counterOffer(player))
    }

    @Test fun clubAcceptsReasonableCounterOffer() {
        assertTrue(TransferNegotiationEngine.acceptsCounter(player, 1_100_000L))
        assertFalse(TransferNegotiationEngine.acceptsCounter(player, 1_200_000L))
    }

    @Test fun agreedSaleValueIsSafelyBounded() {
        assertEquals(1_100_000L, TransferNegotiationEngine.saleRevenue(player, 1_100_000L))
        assertEquals(1_500_000L, TransferNegotiationEngine.saleRevenue(player, 9_000_000L))
    }
    @Test fun sellerAsksTwentyFivePercentAboveMarketValue() {
        assertEquals(1_250_000L, TransferNegotiationEngine.askingPrice(player))
    }

    @Test fun purchaseOfferMustReachTenPercentAboveMarketValue() {
        assertFalse(TransferNegotiationEngine.acceptsPurchaseOffer(player, 1_000_000L))
        assertTrue(TransferNegotiationEngine.acceptsPurchaseOffer(player, 1_100_000L))
        assertTrue(TransferNegotiationEngine.acceptsPurchaseOffer(player, 1_250_000L))
        assertFalse(TransferNegotiationEngine.acceptsPurchaseOffer(player, 1_300_000L))
    }

    @Test fun aiOfferIsStableForSameCareerRoundAndPlayer() {
        val first = TransferNegotiationEngine.generateAiOffer(player, 101, 1, 7)
        val second = TransferNegotiationEngine.generateAiOffer(player, 101, 1, 7)
        assertEquals(first, second)
        assertEquals(player.id, first.playerId)
        assertTrue(first.amount > 0L)
    }

    @Test fun aiOfferChangesWhenRoundChanges() {
        val first = TransferNegotiationEngine.generateAiOffer(player, 101, 1, 7)
        val nextRound = TransferNegotiationEngine.generateAiOffer(player, 101, 1, 8)
        assertNotEquals(first, nextRound)
    }

    @Test fun purchaseFeeUsesAgreedOfferWithinNegotiationRange() {
        assertEquals(1_100_000L, TransferNegotiationEngine.purchaseFee(player, 900_000L))
        assertEquals(1_200_000L, TransferNegotiationEngine.purchaseFee(player, 1_200_000L))
        assertEquals(1_250_000L, TransferNegotiationEngine.purchaseFee(player, 1_500_000L))
    }

}
