package com.futebol27.manager

import org.junit.Assert.*
import org.junit.Test

class PlayerCareerEngineTest {
    private val player = Player(7, "Atleta Teste", "MEI", 22, 75, "01/01/2004", "Brasil", weeklySalary = 10_000)

    @Test fun renewalAcceptsFairOfferAndUpdatesSalaryAndTerm() {
        val state = PlayerCareerState(morale = 80)
        val decision = PlayerCareerEngine.decideRenewal(player, state, ContractOffer(10_000, 16))
        assertTrue(decision.accepted)
        assertEquals(16, decision.state.contractRoundsRemaining)
        assertEquals(10_000L, decision.state.requestedWeeklySalary)
        assertEquals(90, decision.state.morale)
    }

    @Test fun renewalRejectsOfferBelowCurrentWage() {
        val decision = PlayerCareerEngine.decideRenewal(player, PlayerCareerState(morale = 60), ContractOffer(9_000, 12))
        assertFalse(decision.accepted)
        assertEquals(52, decision.state.morale)
    }

    @Test fun matchMoraleRewardsStarterAndWinningTeam() {
        val updated = PlayerCareerEngine.applyMatchResult(PlayerCareerState(morale = 70), started = true, won = true)
        assertEquals(76, updated.morale)
        assertEquals(11, updated.contractRoundsRemaining)
    }
}
